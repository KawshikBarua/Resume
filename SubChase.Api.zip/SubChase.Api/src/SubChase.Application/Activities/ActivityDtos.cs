namespace SubChase.Application.Activities;

public record ActivityDto(
    Guid Id,
    string Type,
    string Message,
    Guid? ClientId,
    string? ClientName,
    string? ClientAvatarColor,
    Guid? DocumentRequestId,
    DateTime CreatedAt);
