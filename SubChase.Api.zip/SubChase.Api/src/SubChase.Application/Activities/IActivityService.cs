using SubChase.Application.Common;

namespace SubChase.Application.Activities;

public interface IActivityService
{
    Task<PagedResult<ActivityDto>> SearchAsync(int page, int pageSize, CancellationToken ct);
    Task<IReadOnlyList<ActivityDto>> GetRecentAsync(int limit, CancellationToken ct);
}
