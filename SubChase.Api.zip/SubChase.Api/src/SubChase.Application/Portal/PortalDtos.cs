namespace SubChase.Application.Portal;

public record PortalContextDto(
    Guid ClientId,
    string BusinessName,
    string ContactName,
    string FirmName,
    string FirmOwnerName,
    string CurrentPeriod,
    IReadOnlyList<PortalRequestDto> Pending,
    IReadOnlyList<PortalRequestDto> Complete);

public record PortalRequestDto(
    Guid Id,
    string Label,
    string? DocumentTypeName,
    bool Required,
    string Status,
    DateTime RequestedAt,
    DateTime? UploadedAt,
    string? FileName);
