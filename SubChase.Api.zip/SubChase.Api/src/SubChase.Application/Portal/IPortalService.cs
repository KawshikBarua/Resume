using SubChase.Application.Documents;

namespace SubChase.Application.Portal;

// All methods take a portal token (the public, unguessable per-client identifier),
// not a Guid Id — the token is the only authorization the client portal has.
public interface IPortalService
{
    Task<PortalContextDto> GetContextAsync(string portalToken, CancellationToken ct);

    Task<DocumentRequestDto> UploadAsync(
        string portalToken,
        Guid requestId,
        string fileName,
        string contentType,
        Stream content,
        long size,
        CancellationToken ct);
}
