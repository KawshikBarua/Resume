namespace SubChase.Application.Templates;

public record TemplateDto(
    Guid Id,
    string Name,
    string? Description,
    string Cadence,
    IReadOnlyList<TemplateItemDto> Items,
    DateTime CreatedAt);

public record TemplateItemDto(
    Guid Id,
    string Label,
    string? Description,
    bool Required,
    int Order);

public record CreateTemplateRequest(
    string Name,
    string? Description,
    string Cadence,
    IReadOnlyList<CreateTemplateItemRequest> Items);

public record CreateTemplateItemRequest(
    string Label,
    string? Description,
    bool Required);

public record UpdateTemplateRequest(
    string Name,
    string? Description,
    string Cadence,
    IReadOnlyList<CreateTemplateItemRequest> Items);

public record ApplyTemplateRequest(
    Guid TemplateId,
    Guid ClientId,
    string Period);
