namespace SubChase.Application.Templates;

public interface ITemplateService
{
    Task<IReadOnlyList<TemplateDto>> ListAsync(CancellationToken ct);
    Task<TemplateDto> GetAsync(Guid id, CancellationToken ct);
    Task<TemplateDto> CreateAsync(CreateTemplateRequest req, CancellationToken ct);
    Task<TemplateDto> UpdateAsync(Guid id, UpdateTemplateRequest req, CancellationToken ct);
    Task DeleteAsync(Guid id, CancellationToken ct);

    // Apply a template to a client for a specific period; creates DocumentRequests
    Task<int> ApplyAsync(ApplyTemplateRequest req, CancellationToken ct);
}
