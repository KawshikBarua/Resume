namespace SubChase.Application.Clients;

public record ClientDto(
    Guid Id,
    string BusinessName,
    string Industry,
    string ContactName,
    string ContactEmail,
    string? ContactPhone,
    string? Notes,
    string Status,
    string AvatarColor,
    string PortalToken,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record ClientProgressDto(
    Guid Id,
    string BusinessName,
    string Industry,
    string ContactName,
    string ContactEmail,
    string AvatarColor,
    int RequestsTotal,
    int RequestsReceived,
    DateTime? LastUploadAt,
    bool Overdue);

public record CreateClientRequest(
    string BusinessName,
    string Industry,
    string ContactName,
    string ContactEmail,
    string? ContactPhone,
    string? Notes);

public record UpdateClientRequest(
    string BusinessName,
    string Industry,
    string ContactName,
    string ContactEmail,
    string? ContactPhone,
    string? Notes);
