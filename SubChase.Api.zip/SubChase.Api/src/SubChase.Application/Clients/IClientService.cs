using SubChase.Application.Common;

namespace SubChase.Application.Clients;

public interface IClientService
{
    Task<PagedResult<ClientProgressDto>> SearchAsync(
        string? search, string? sort, int page, int pageSize, CancellationToken ct);

    Task<ClientDto> GetAsync(Guid id, CancellationToken ct);
    Task<ClientDto> CreateAsync(CreateClientRequest req, CancellationToken ct);
    Task<ClientDto> UpdateAsync(Guid id, UpdateClientRequest req, CancellationToken ct);
    Task ArchiveAsync(Guid id, CancellationToken ct);
    Task RestoreAsync(Guid id, CancellationToken ct);
    Task DeleteAsync(Guid id, CancellationToken ct);

    Task SendReminderAsync(Guid id, CancellationToken ct);
}
