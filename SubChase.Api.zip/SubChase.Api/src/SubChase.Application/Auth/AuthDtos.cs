namespace SubChase.Application.Auth;

public record RegisterRequest(
    string FirmName,
    string OwnerName,
    string Email,
    string Password);

public record LoginRequest(string Email, string Password);

public record AuthResponse(
    string AccessToken,
    DateTime ExpiresAt,
    UserDto User,
    FirmDto Firm);

public record UserDto(
    Guid Id,
    string FullName,
    string Email);

public record FirmDto(
    Guid Id,
    string Name,
    string OwnerName,
    string Email,
    string? Phone,
    string Timezone,
    string Plan,
    bool ReminderMondayEnabled,
    bool ReminderThursdayEnabled,
    string ReminderTimeOfDay);

public record UpdateFirmRequest(
    string Name,
    string OwnerName,
    string Email,
    string? Phone,
    string Timezone,
    bool ReminderMondayEnabled,
    bool ReminderThursdayEnabled,
    string ReminderTimeOfDay);
