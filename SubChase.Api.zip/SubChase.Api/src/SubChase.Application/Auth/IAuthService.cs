namespace SubChase.Application.Auth;

public interface IAuthService
{
    Task<AuthResponse> RegisterAsync(RegisterRequest req, CancellationToken ct);
    Task<AuthResponse> LoginAsync(LoginRequest req, CancellationToken ct);
    Task<AuthResponse> CurrentAsync(CancellationToken ct);
    Task<FirmDto> UpdateFirmAsync(UpdateFirmRequest req, CancellationToken ct);
}
