using SubChase.Application.Common;

namespace SubChase.Application.Documents;

public interface IDocumentService
{
    Task<PagedResult<DocumentRequestDto>> SearchAsync(
        string? search,
        string? status,
        string? period,
        Guid? clientId,
        int page,
        int pageSize,
        CancellationToken ct);

    Task<DocumentRequestDto> GetAsync(Guid id, CancellationToken ct);

    Task<DocumentRequestDto> CreateAsync(CreateDocumentRequestRequest req, CancellationToken ct);

    // Upload file from staff app
    Task<DocumentRequestDto> UploadFileAsync(
        Guid requestId,
        string fileName,
        string contentType,
        Stream content,
        long size,
        CancellationToken ct);

    // Returns the raw bytes for download
    Task<(byte[] Bytes, string ContentType, string FileName)> DownloadFileAsync(
        Guid requestId, CancellationToken ct);

    Task<DocumentRequestDto> MarkReviewedAsync(Guid id, CancellationToken ct);
    Task<DocumentRequestDto> RerequestAsync(Guid id, CancellationToken ct);
    Task<DocumentRequestDto> AddCommentAsync(Guid id, AddCommentRequest req, CancellationToken ct);
    Task DeleteAsync(Guid id, CancellationToken ct);

    // KPIs
    Task<OverallStatsDto> GetOverallStatsAsync(CancellationToken ct);

    // Per-client requests for current period (used by Dashboard chase list)
    Task<IReadOnlyList<DocumentRequestDto>> GetCurrentMonthForClientAsync(
        Guid clientId, CancellationToken ct);
}
