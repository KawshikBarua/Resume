namespace SubChase.Application.Documents;

public record DocumentRequestDto(
    Guid Id,
    Guid ClientId,
    string ClientName,
    string ClientAvatarColor,
    string Period,
    string Label,
    string? DocumentTypeName,
    bool Required,
    string Status,
    DateTime RequestedAt,
    DateTime? UploadedAt,
    DateTime? ReviewedAt,
    string? ReviewerComment,
    bool Archived,
    string? FileName,
    long? FileSize,
    string? ContentType,
    bool Overdue);

public record CreateDocumentRequestRequest(
    Guid ClientId,
    string Period,
    string Label,
    string? DocumentTypeName,
    bool Required);

public record AddCommentRequest(string Comment);

public record OverallStatsDto(
    int Total,
    int Received,
    int Reviewed,
    int Pending,
    int Overdue,
    int ClientsCount);
