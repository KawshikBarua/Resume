namespace SubChase.Application.Common;

public class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; init; } = Array.Empty<T>();
    public int Total { get; init; }
    public int Page { get; init; }
    public int PageSize { get; init; }
}

// Resolved from JWT claims at the start of each request
public interface ICurrentUser
{
    Guid? UserId { get; }
    Guid? FirmId { get; }
    string? Email { get; }
    bool IsAuthenticated { get; }
}
