using SubChase.Domain.Common;
using SubChase.Domain.Enums;

namespace SubChase.Domain.Entities;

public class Firm : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string OwnerName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string Timezone { get; set; } = "UTC";
    public PlanTier Plan { get; set; } = PlanTier.Solo;

    // Email reminder cadence config (days of week as JSON or simple bitmask)
    public bool ReminderMondayEnabled { get; set; } = true;
    public bool ReminderThursdayEnabled { get; set; } = true;
    public string ReminderTimeOfDay { get; set; } = "09:00";

    // Relationships
    public ICollection<AppUser> Users { get; set; } = new List<AppUser>();
    public ICollection<Client> Clients { get; set; } = new List<Client>();
    public ICollection<DocumentTemplate> Templates { get; set; } = new List<DocumentTemplate>();
    public ICollection<Activity> Activities { get; set; } = new List<Activity>();
}
