using SubChase.Domain.Common;

namespace SubChase.Domain.Entities;

public class DocumentTemplate : BaseEntity
{
    public Guid FirmId { get; set; }
    public Firm Firm { get; set; } = null!;

    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }

    // How often this template should be applied: "monthly", "quarterly", "annual"
    public string Cadence { get; set; } = "monthly";

    public ICollection<DocumentTemplateItem> Items { get; set; } = new List<DocumentTemplateItem>();
}

public class DocumentTemplateItem : BaseEntity
{
    public Guid TemplateId { get; set; }
    public DocumentTemplate Template { get; set; } = null!;

    public string Label { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool Required { get; set; } = true;
    public int Order { get; set; }
}
