using SubChase.Domain.Common;
using SubChase.Domain.Enums;

namespace SubChase.Domain.Entities;

public class Client : BaseEntity
{
    public Guid FirmId { get; set; }
    public Firm Firm { get; set; } = null!;

    public string BusinessName { get; set; } = string.Empty;
    public string Industry { get; set; } = string.Empty;
    public string ContactName { get; set; } = string.Empty;
    public string ContactEmail { get; set; } = string.Empty;
    public string? ContactPhone { get; set; }
    public string? Notes { get; set; }

    public ClientStatus Status { get; set; } = ClientStatus.Active;

    // Random color hex like "#b8895f" used for avatars in the UI
    public string AvatarColor { get; set; } = "#b8895f";

    // Token used in the public portal URL: /portal/{PortalToken}
    public string PortalToken { get; set; } = Guid.NewGuid().ToString("N");

    public ICollection<DocumentRequest> Requests { get; set; } = new List<DocumentRequest>();
}
