using SubChase.Domain.Common;
using SubChase.Domain.Enums;

namespace SubChase.Domain.Entities;

public class Activity : BaseEntity
{
    public Guid FirmId { get; set; }
    public Firm Firm { get; set; } = null!;

    public Guid? ClientId { get; set; }
    public Client? Client { get; set; }

    public Guid? DocumentRequestId { get; set; }
    public DocumentRequest? DocumentRequest { get; set; }

    public Guid? ActorUserId { get; set; }

    public ActivityType Type { get; set; }
    public string Message { get; set; } = string.Empty;
}
