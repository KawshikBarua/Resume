using Microsoft.AspNetCore.Identity;

namespace SubChase.Domain.Entities;

// Extends ASP.NET Core Identity user with firm scoping + display data
public class AppUser : IdentityUser<Guid>
{
    public string FullName { get; set; } = string.Empty;
    public Guid FirmId { get; set; }
    public Firm Firm { get; set; } = null!;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
