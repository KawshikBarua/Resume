using SubChase.Domain.Common;
using SubChase.Domain.Enums;

namespace SubChase.Domain.Entities;

public class DocumentRequest : BaseEntity
{
    public Guid ClientId { get; set; }
    public Client Client { get; set; } = null!;

    // The period this request belongs to, e.g. "May 2026" or "Q2 2026"
    public string Period { get; set; } = string.Empty;

    public string Label { get; set; } = string.Empty;
    public string? DocumentTypeName { get; set; }
    public bool Required { get; set; } = true;

    public DocumentRequestStatus Status { get; set; } = DocumentRequestStatus.Requested;

    public DateTime RequestedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UploadedAt { get; set; }
    public DateTime? ReviewedAt { get; set; }

    public string? ReviewerComment { get; set; }
    public bool Archived { get; set; } = false;

    // Single file per request (can extend to many later)
    public Guid? StoredFileId { get; set; }
    public StoredFile? StoredFile { get; set; }
}

public class StoredFile : BaseEntity
{
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = "application/octet-stream";
    public long FileSize { get; set; }

    // Raw bytes stored in Postgres as bytea
    public byte[] Content { get; set; } = Array.Empty<byte>();

    public Guid UploadedByFirmId { get; set; }
    // Null when uploaded via public portal
    public Guid? UploadedByUserId { get; set; }
}
