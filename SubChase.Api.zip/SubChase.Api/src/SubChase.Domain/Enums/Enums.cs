namespace SubChase.Domain.Enums;

public enum DocumentRequestStatus
{
    Requested = 0,
    Received = 1,
    Reviewed = 2
}

public enum ClientStatus
{
    Active = 0,
    Archived = 1
}

public enum PlanTier
{
    Solo = 0,
    Studio = 1,
    Firm = 2
}

public enum ActivityType
{
    DocumentRequested = 0,
    DocumentUploaded = 1,
    DocumentReviewed = 2,
    DocumentRerequested = 3,
    CommentAdded = 4,
    ReminderSent = 5,
    ClientAdded = 6,
    ClientArchived = 7,
    TemplateApplied = 8
}
