using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SubChase.Domain.Entities;
using SubChase.Domain.Enums;
using SubChase.Infrastructure.Data;

namespace SubChase.Api.Setup;

public static class DatabaseSeeder
{
    // Creates a demo firm + user the first time the API starts, so the React
    // app can log in immediately. Idempotent: re-runs are no-ops.
    public static async Task SeedAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var users = scope.ServiceProvider.GetRequiredService<UserManager<AppUser>>();

        await db.Database.MigrateAsync();

        const string demoEmail = "demo@subchase.app";
        if (await users.FindByEmailAsync(demoEmail) is not null) return;

        var firm = new Firm
        {
            Name = "Whitmore & Co. Bookkeeping",
            OwnerName = "Eleanor Whitmore",
            Email = demoEmail,
            Phone = "+1 (415) 555-0142",
            Timezone = "America/Los_Angeles",
            Plan = PlanTier.Studio,
        };
        db.Firms.Add(firm);
        await db.SaveChangesAsync();

        var user = new AppUser
        {
            UserName = demoEmail,
            Email = demoEmail,
            EmailConfirmed = true,
            FullName = "Eleanor Whitmore",
            FirmId = firm.Id,
        };
        var result = await users.CreateAsync(user, "demo1234");
        if (!result.Succeeded)
        {
            // If the user couldn't be created for some reason, roll back the firm so the
            // next startup tries again cleanly.
            db.Firms.Remove(firm);
            await db.SaveChangesAsync();
            throw new Exception("Seed failed: " +
                string.Join("; ", result.Errors.Select(e => e.Description)));
        }

        // Two example clients + a starter template so the dashboard isn't empty
        var c1 = new Client
        {
            FirmId = firm.Id,
            BusinessName = "Lumière Coffee Roasters",
            Industry = "Food & Beverage",
            ContactName = "Marcus Chen",
            ContactEmail = "marcus@lumierecoffee.com",
            AvatarColor = "#b8895f",
        };
        var c2 = new Client
        {
            FirmId = firm.Id,
            BusinessName = "Cedar & Stone Construction",
            Industry = "Construction",
            ContactName = "James Whitfield",
            ContactEmail = "james@cedarstone.build",
            AvatarColor = "#6b8068",
        };
        db.Clients.AddRange(c1, c2);

        var template = new DocumentTemplate
        {
            FirmId = firm.Id,
            Name = "Monthly bookkeeping checklist",
            Description = "Standard month-end docs for small businesses.",
            Cadence = "monthly",
            Items = new List<DocumentTemplateItem>
            {
                new() { Label = "Business checking statement", Required = true, Order = 0 },
                new() { Label = "Credit card statements", Required = true, Order = 1 },
                new() { Label = "Receipts folder", Required = false, Order = 2 },
                new() { Label = "Payroll summary", Required = true, Order = 3 },
            },
        };
        db.Templates.Add(template);

        await db.SaveChangesAsync();
    }
}
