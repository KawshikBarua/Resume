using Microsoft.AspNetCore.Http;
using SubChase.Application.Common;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace SubChase.Api.Auth;

public class CurrentUser : ICurrentUser
{
    private readonly IHttpContextAccessor _http;
    public CurrentUser(IHttpContextAccessor http) { _http = http; }

    public bool IsAuthenticated => _http.HttpContext?.User?.Identity?.IsAuthenticated ?? false;

    public Guid? UserId
    {
        get
        {
            var sub = _http.HttpContext?.User?.FindFirst(JwtRegisteredClaimNames.Sub)?.Value
                   ?? _http.HttpContext?.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return Guid.TryParse(sub, out var g) ? g : null;
        }
    }

    public Guid? FirmId
    {
        get
        {
            var v = _http.HttpContext?.User?.FindFirst("firm_id")?.Value;
            return Guid.TryParse(v, out var g) ? g : null;
        }
    }

    public string? Email =>
        _http.HttpContext?.User?.FindFirst(JwtRegisteredClaimNames.Email)?.Value
        ?? _http.HttpContext?.User?.FindFirst(ClaimTypes.Email)?.Value;
}
