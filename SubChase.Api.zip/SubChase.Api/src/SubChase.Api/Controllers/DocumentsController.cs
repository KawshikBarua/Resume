using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubChase.Application.Common;
using SubChase.Application.Documents;

namespace SubChase.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/documents")]
public class DocumentsController : ControllerBase
{
    private readonly IDocumentService _service;
    public DocumentsController(IDocumentService service) { _service = service; }

    [HttpGet]
    public async Task<ActionResult<PagedResult<DocumentRequestDto>>> List(
        [FromQuery] string? search,
        [FromQuery] string? status,
        [FromQuery] string? period,
        [FromQuery] Guid? clientId,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        CancellationToken ct = default)
        => await _service.SearchAsync(search, status, period, clientId, page, pageSize, ct);

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<DocumentRequestDto>> Get(Guid id, CancellationToken ct)
        => await _service.GetAsync(id, ct);

    [HttpPost]
    public async Task<ActionResult<DocumentRequestDto>> Create(
        [FromBody] CreateDocumentRequestRequest req, CancellationToken ct)
    {
        var r = await _service.CreateAsync(req, ct);
        return CreatedAtAction(nameof(Get), new { id = r.Id }, r);
    }

    [HttpPost("{id:guid}/upload")]
    [RequestSizeLimit(100 * 1024 * 1024)] // 100 MB
    public async Task<ActionResult<DocumentRequestDto>> Upload(
        Guid id, [FromForm] IFormFile file, CancellationToken ct)
    {
        if (file is null || file.Length == 0)
            return BadRequest(new { error = "No file provided." });

        await using var stream = file.OpenReadStream();
        var dto = await _service.UploadFileAsync(
            id, file.FileName, file.ContentType ?? "application/octet-stream",
            stream, file.Length, ct);
        return dto;
    }

    [HttpGet("{id:guid}/download")]
    public async Task<IActionResult> Download(Guid id, CancellationToken ct)
    {
        var (bytes, contentType, fileName) = await _service.DownloadFileAsync(id, ct);
        return File(bytes, contentType, fileName);
    }

    [HttpPost("{id:guid}/review")]
    public async Task<ActionResult<DocumentRequestDto>> MarkReviewed(Guid id, CancellationToken ct)
        => await _service.MarkReviewedAsync(id, ct);

    [HttpPost("{id:guid}/rerequest")]
    public async Task<ActionResult<DocumentRequestDto>> Rerequest(Guid id, CancellationToken ct)
        => await _service.RerequestAsync(id, ct);

    [HttpPost("{id:guid}/comment")]
    public async Task<ActionResult<DocumentRequestDto>> Comment(
        Guid id, [FromBody] AddCommentRequest req, CancellationToken ct)
        => await _service.AddCommentAsync(id, req, ct);

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await _service.DeleteAsync(id, ct);
        return NoContent();
    }

    [HttpGet("stats")]
    public async Task<ActionResult<OverallStatsDto>> Stats(CancellationToken ct)
        => await _service.GetOverallStatsAsync(ct);
}
