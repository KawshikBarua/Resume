using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubChase.Application.Templates;

namespace SubChase.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/templates")]
public class TemplatesController : ControllerBase
{
    private readonly ITemplateService _service;
    public TemplatesController(ITemplateService service) { _service = service; }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<TemplateDto>>> List(CancellationToken ct)
        => Ok(await _service.ListAsync(ct));

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<TemplateDto>> Get(Guid id, CancellationToken ct)
        => await _service.GetAsync(id, ct);

    [HttpPost]
    public async Task<ActionResult<TemplateDto>> Create(
        [FromBody] CreateTemplateRequest req, CancellationToken ct)
    {
        var t = await _service.CreateAsync(req, ct);
        return CreatedAtAction(nameof(Get), new { id = t.Id }, t);
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<TemplateDto>> Update(
        Guid id, [FromBody] UpdateTemplateRequest req, CancellationToken ct)
        => await _service.UpdateAsync(id, req, ct);

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await _service.DeleteAsync(id, ct);
        return NoContent();
    }

    [HttpPost("apply")]
    public async Task<ActionResult<object>> Apply(
        [FromBody] ApplyTemplateRequest req, CancellationToken ct)
    {
        var created = await _service.ApplyAsync(req, ct);
        return Ok(new { created });
    }
}
