using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubChase.Application.Auth;

namespace SubChase.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _service;
    public AuthController(IAuthService service) { _service = service; }

    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Register(
        [FromBody] RegisterRequest req, CancellationToken ct)
        => await _service.RegisterAsync(req, ct);

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Login(
        [FromBody] LoginRequest req, CancellationToken ct)
        => await _service.LoginAsync(req, ct);

    [HttpGet("me")]
    [Authorize]
    public async Task<ActionResult<AuthResponse>> Me(CancellationToken ct)
        => await _service.CurrentAsync(ct);

    [HttpPut("firm")]
    [Authorize]
    public async Task<ActionResult<FirmDto>> UpdateFirm(
        [FromBody] UpdateFirmRequest req, CancellationToken ct)
        => await _service.UpdateFirmAsync(req, ct);
}
