using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubChase.Application.Activities;
using SubChase.Application.Common;

namespace SubChase.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/activities")]
public class ActivitiesController : ControllerBase
{
    private readonly IActivityService _service;
    public ActivitiesController(IActivityService service) { _service = service; }

    [HttpGet]
    public async Task<ActionResult<PagedResult<ActivityDto>>> List(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        CancellationToken ct = default)
        => await _service.SearchAsync(page, pageSize, ct);

    [HttpGet("recent")]
    public async Task<ActionResult<IReadOnlyList<ActivityDto>>> Recent(
        [FromQuery] int limit = 10, CancellationToken ct = default)
        => Ok(await _service.GetRecentAsync(limit, ct));
}
