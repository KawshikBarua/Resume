using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubChase.Application.Clients;
using SubChase.Application.Common;
using SubChase.Application.Documents;

namespace SubChase.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/clients")]
public class ClientsController : ControllerBase
{
    private readonly IClientService _clients;
    private readonly IDocumentService _documents;

    public ClientsController(IClientService clients, IDocumentService documents)
    {
        _clients = clients; _documents = documents;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<ClientProgressDto>>> List(
        [FromQuery] string? search,
        [FromQuery] string? sort,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        CancellationToken ct = default)
        => await _clients.SearchAsync(search, sort, page, pageSize, ct);

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<ClientDto>> Get(Guid id, CancellationToken ct)
        => await _clients.GetAsync(id, ct);

    [HttpGet("{id:guid}/requests/current")]
    public async Task<ActionResult<IReadOnlyList<DocumentRequestDto>>> CurrentRequests(
        Guid id, CancellationToken ct)
        => Ok(await _documents.GetCurrentMonthForClientAsync(id, ct));

    [HttpPost]
    public async Task<ActionResult<ClientDto>> Create(
        [FromBody] CreateClientRequest req, CancellationToken ct)
    {
        var c = await _clients.CreateAsync(req, ct);
        return CreatedAtAction(nameof(Get), new { id = c.Id }, c);
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<ClientDto>> Update(
        Guid id, [FromBody] UpdateClientRequest req, CancellationToken ct)
        => await _clients.UpdateAsync(id, req, ct);

    [HttpPost("{id:guid}/archive")]
    public async Task<IActionResult> Archive(Guid id, CancellationToken ct)
    {
        await _clients.ArchiveAsync(id, ct);
        return NoContent();
    }

    [HttpPost("{id:guid}/restore")]
    public async Task<IActionResult> Restore(Guid id, CancellationToken ct)
    {
        await _clients.RestoreAsync(id, ct);
        return NoContent();
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await _clients.DeleteAsync(id, ct);
        return NoContent();
    }

    [HttpPost("{id:guid}/nudge")]
    public async Task<IActionResult> Nudge(Guid id, CancellationToken ct)
    {
        await _clients.SendReminderAsync(id, ct);
        return NoContent();
    }
}
