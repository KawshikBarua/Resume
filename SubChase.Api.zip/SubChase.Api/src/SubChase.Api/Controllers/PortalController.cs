using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubChase.Application.Documents;
using SubChase.Application.Portal;

namespace SubChase.Api.Controllers;

// Public client portal — no auth, identified by the per-client PortalToken.
[ApiController]
[AllowAnonymous]
[Route("api/portal/{token}")]
public class PortalController : ControllerBase
{
    private readonly IPortalService _service;
    public PortalController(IPortalService service) { _service = service; }

    [HttpGet]
    public async Task<ActionResult<PortalContextDto>> Context(string token, CancellationToken ct)
        => await _service.GetContextAsync(token, ct);

    [HttpPost("requests/{requestId:guid}/upload")]
    [RequestSizeLimit(100 * 1024 * 1024)] // 100 MB
    public async Task<ActionResult<DocumentRequestDto>> Upload(
        string token, Guid requestId, [FromForm] IFormFile file, CancellationToken ct)
    {
        if (file is null || file.Length == 0)
            return BadRequest(new { error = "No file provided." });

        await using var stream = file.OpenReadStream();
        var dto = await _service.UploadAsync(
            token, requestId, file.FileName,
            file.ContentType ?? "application/octet-stream",
            stream, file.Length, ct);
        return dto;
    }
}
