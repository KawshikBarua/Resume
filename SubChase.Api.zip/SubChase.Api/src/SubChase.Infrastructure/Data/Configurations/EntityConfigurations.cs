using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SubChase.Domain.Entities;

namespace SubChase.Infrastructure.Data.Configurations;

public class FirmConfig : IEntityTypeConfiguration<Firm>
{
    public void Configure(EntityTypeBuilder<Firm> b)
    {
        b.ToTable("firms");
        b.HasKey(x => x.Id);
        b.Property(x => x.Name).IsRequired().HasMaxLength(200);
        b.Property(x => x.OwnerName).IsRequired().HasMaxLength(200);
        b.Property(x => x.Email).IsRequired().HasMaxLength(256);
        b.Property(x => x.Phone).HasMaxLength(50);
        b.Property(x => x.Timezone).IsRequired().HasMaxLength(100);
        b.Property(x => x.ReminderTimeOfDay).HasMaxLength(10);
        b.Property(x => x.Plan).HasConversion<string>();
        b.HasIndex(x => x.Email).IsUnique();
    }
}

public class ClientConfig : IEntityTypeConfiguration<Client>
{
    public void Configure(EntityTypeBuilder<Client> b)
    {
        b.ToTable("clients");
        b.HasKey(x => x.Id);
        b.Property(x => x.BusinessName).IsRequired().HasMaxLength(200);
        b.Property(x => x.Industry).IsRequired().HasMaxLength(100);
        b.Property(x => x.ContactName).IsRequired().HasMaxLength(200);
        b.Property(x => x.ContactEmail).IsRequired().HasMaxLength(256);
        b.Property(x => x.ContactPhone).HasMaxLength(50);
        b.Property(x => x.Notes).HasMaxLength(2000);
        b.Property(x => x.AvatarColor).HasMaxLength(20);
        b.Property(x => x.PortalToken).IsRequired().HasMaxLength(64);
        b.Property(x => x.Status).HasConversion<string>();

        b.HasIndex(x => x.PortalToken).IsUnique();
        b.HasIndex(x => new { x.FirmId, x.BusinessName });

        b.HasOne(x => x.Firm)
            .WithMany(f => f.Clients)
            .HasForeignKey(x => x.FirmId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}

public class TemplateConfig : IEntityTypeConfiguration<DocumentTemplate>
{
    public void Configure(EntityTypeBuilder<DocumentTemplate> b)
    {
        b.ToTable("document_templates");
        b.HasKey(x => x.Id);
        b.Property(x => x.Name).IsRequired().HasMaxLength(200);
        b.Property(x => x.Description).HasMaxLength(1000);
        b.Property(x => x.Cadence).HasMaxLength(20);
        b.HasIndex(x => new { x.FirmId, x.Name });

        b.HasOne(x => x.Firm)
            .WithMany(f => f.Templates)
            .HasForeignKey(x => x.FirmId)
            .OnDelete(DeleteBehavior.Cascade);

        b.HasMany(x => x.Items)
            .WithOne(i => i.Template)
            .HasForeignKey(i => i.TemplateId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}

public class TemplateItemConfig : IEntityTypeConfiguration<DocumentTemplateItem>
{
    public void Configure(EntityTypeBuilder<DocumentTemplateItem> b)
    {
        b.ToTable("document_template_items");
        b.HasKey(x => x.Id);
        b.Property(x => x.Label).IsRequired().HasMaxLength(200);
        b.Property(x => x.Description).HasMaxLength(500);
    }
}

public class DocumentRequestConfig : IEntityTypeConfiguration<DocumentRequest>
{
    public void Configure(EntityTypeBuilder<DocumentRequest> b)
    {
        b.ToTable("document_requests");
        b.HasKey(x => x.Id);
        b.Property(x => x.Period).IsRequired().HasMaxLength(50);
        b.Property(x => x.Label).IsRequired().HasMaxLength(200);
        b.Property(x => x.DocumentTypeName).HasMaxLength(100);
        b.Property(x => x.ReviewerComment).HasMaxLength(2000);
        b.Property(x => x.Status).HasConversion<string>();

        b.HasIndex(x => new { x.ClientId, x.Period });
        b.HasIndex(x => x.Status);

        b.HasOne(x => x.Client)
            .WithMany(c => c.Requests)
            .HasForeignKey(x => x.ClientId)
            .OnDelete(DeleteBehavior.Cascade);

        b.HasOne(x => x.StoredFile)
            .WithMany()
            .HasForeignKey(x => x.StoredFileId)
            .OnDelete(DeleteBehavior.SetNull);
    }
}

public class StoredFileConfig : IEntityTypeConfiguration<StoredFile>
{
    public void Configure(EntityTypeBuilder<StoredFile> b)
    {
        b.ToTable("stored_files");
        b.HasKey(x => x.Id);
        b.Property(x => x.FileName).IsRequired().HasMaxLength(500);
        b.Property(x => x.ContentType).IsRequired().HasMaxLength(200);
        // Postgres bytea
        b.Property(x => x.Content).HasColumnType("bytea").IsRequired();
    }
}

public class ActivityConfig : IEntityTypeConfiguration<Activity>
{
    public void Configure(EntityTypeBuilder<Activity> b)
    {
        b.ToTable("activities");
        b.HasKey(x => x.Id);
        b.Property(x => x.Type).HasConversion<string>();
        b.Property(x => x.Message).IsRequired().HasMaxLength(500);

        b.HasIndex(x => new { x.FirmId, x.CreatedAt });

        b.HasOne(x => x.Firm)
            .WithMany(f => f.Activities)
            .HasForeignKey(x => x.FirmId)
            .OnDelete(DeleteBehavior.Cascade);

        b.HasOne(x => x.Client)
            .WithMany()
            .HasForeignKey(x => x.ClientId)
            .OnDelete(DeleteBehavior.SetNull);

        b.HasOne(x => x.DocumentRequest)
            .WithMany()
            .HasForeignKey(x => x.DocumentRequestId)
            .OnDelete(DeleteBehavior.SetNull);
    }
}
