using Microsoft.IdentityModel.Tokens;
using SubChase.Domain.Entities;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace SubChase.Infrastructure.Auth;

public class JwtOptions
{
    public string Issuer { get; set; } = "subchase";
    public string Audience { get; set; } = "subchase";
    // 32+ chars; should come from env/secrets in production
    public string SigningKey { get; set; } = "dev-only-signing-key-please-change-me-32+";
    public int AccessTokenLifetimeHours { get; set; } = 24;
}

public interface IJwtTokenGenerator
{
    (string Token, DateTime ExpiresAt) Generate(AppUser user);
}

public class JwtTokenGenerator : IJwtTokenGenerator
{
    private readonly JwtOptions _options;
    public JwtTokenGenerator(JwtOptions options) { _options = options; }

    public (string Token, DateTime ExpiresAt) Generate(AppUser user)
    {
        var expires = DateTime.UtcNow.AddHours(_options.AccessTokenLifetimeHours);

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new(JwtRegisteredClaimNames.Email, user.Email ?? ""),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new("firm_id", user.FirmId.ToString()),
            new("name", user.FullName),
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.SigningKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _options.Issuer,
            audience: _options.Audience,
            claims: claims,
            expires: expires,
            signingCredentials: creds);

        return (new JwtSecurityTokenHandler().WriteToken(token), expires);
    }
}
