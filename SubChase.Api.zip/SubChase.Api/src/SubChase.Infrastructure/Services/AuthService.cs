using FluentValidation;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SubChase.Application.Auth;
using SubChase.Application.Common;
using SubChase.Domain.Entities;
using SubChase.Domain.Enums;
using SubChase.Domain.Exceptions;
using SubChase.Infrastructure.Auth;
using SubChase.Infrastructure.Data;

namespace SubChase.Infrastructure.Services;

public class AuthService : IAuthService
{
    private readonly AppDbContext _db;
    private readonly UserManager<AppUser> _users;
    private readonly SignInManager<AppUser> _signIn;
    private readonly IJwtTokenGenerator _jwt;
    private readonly ICurrentUser _current;
    private readonly IValidator<RegisterRequest> _registerValidator;
    private readonly IValidator<LoginRequest> _loginValidator;
    private readonly IValidator<UpdateFirmRequest> _updateFirmValidator;

    public AuthService(
        AppDbContext db,
        UserManager<AppUser> users,
        SignInManager<AppUser> signIn,
        IJwtTokenGenerator jwt,
        ICurrentUser current,
        IValidator<RegisterRequest> registerValidator,
        IValidator<LoginRequest> loginValidator,
        IValidator<UpdateFirmRequest> updateFirmValidator)
    {
        _db = db;
        _users = users;
        _signIn = signIn;
        _jwt = jwt;
        _current = current;
        _registerValidator = registerValidator;
        _loginValidator = loginValidator;
        _updateFirmValidator = updateFirmValidator;
    }

    public async Task<AuthResponse> RegisterAsync(RegisterRequest req, CancellationToken ct)
    {
        await _registerValidator.ValidateAndThrowAsync(req, ct);

        var existing = await _users.FindByEmailAsync(req.Email);
        if (existing != null)
            throw new DomainException("An account with that email already exists.");

        // Create firm + first user in one transaction
        await using var tx = await _db.Database.BeginTransactionAsync(ct);

        var firm = new Firm
        {
            Name = req.FirmName,
            OwnerName = req.OwnerName,
            Email = req.Email,
        };
        _db.Firms.Add(firm);
        await _db.SaveChangesAsync(ct);

        var user = new AppUser
        {
            UserName = req.Email,
            Email = req.Email,
            EmailConfirmed = true,
            FullName = req.OwnerName,
            FirmId = firm.Id,
        };

        var result = await _users.CreateAsync(user, req.Password);
        if (!result.Succeeded)
        {
            var errors = result.Errors.ToDictionary(
                e => e.Code, e => new[] { e.Description });
            throw new Domain.Exceptions.ValidationException(errors);
        }

        await tx.CommitAsync(ct);
        return BuildAuthResponse(user, firm);
    }

    public async Task<AuthResponse> LoginAsync(LoginRequest req, CancellationToken ct)
    {
        await _loginValidator.ValidateAndThrowAsync(req, ct);

        var user = await _users.FindByEmailAsync(req.Email);
        if (user == null)
            throw new DomainException("Invalid email or password.");

        var check = await _signIn.CheckPasswordSignInAsync(user, req.Password, lockoutOnFailure: false);
        if (!check.Succeeded)
            throw new DomainException("Invalid email or password.");

        var firm = await _db.Firms.AsNoTracking()
            .FirstOrDefaultAsync(f => f.Id == user.FirmId, ct)
            ?? throw new NotFoundException("Firm", user.FirmId);

        return BuildAuthResponse(user, firm);
    }

    public async Task<AuthResponse> CurrentAsync(CancellationToken ct)
    {
        if (!_current.IsAuthenticated || _current.UserId is null)
            throw new ForbiddenException();

        var user = await _users.Users.FirstOrDefaultAsync(u => u.Id == _current.UserId, ct)
            ?? throw new NotFoundException("User", _current.UserId);
        var firm = await _db.Firms.AsNoTracking().FirstOrDefaultAsync(f => f.Id == user.FirmId, ct)
            ?? throw new NotFoundException("Firm", user.FirmId);

        return BuildAuthResponse(user, firm);
    }

    public async Task<FirmDto> UpdateFirmAsync(UpdateFirmRequest req, CancellationToken ct)
    {
        await _updateFirmValidator.ValidateAndThrowAsync(req, ct);

        if (_current.FirmId is null) throw new ForbiddenException();
        var firm = await _db.Firms.FirstOrDefaultAsync(f => f.Id == _current.FirmId, ct)
            ?? throw new NotFoundException("Firm", _current.FirmId);

        firm.Name = req.Name;
        firm.OwnerName = req.OwnerName;
        firm.Email = req.Email;
        firm.Phone = req.Phone;
        firm.Timezone = req.Timezone;
        firm.ReminderMondayEnabled = req.ReminderMondayEnabled;
        firm.ReminderThursdayEnabled = req.ReminderThursdayEnabled;
        firm.ReminderTimeOfDay = req.ReminderTimeOfDay;

        await _db.SaveChangesAsync(ct);
        return ToFirmDto(firm);
    }

    private AuthResponse BuildAuthResponse(AppUser user, Firm firm)
    {
        var (token, expires) = _jwt.Generate(user);
        return new AuthResponse(
            token,
            expires,
            new UserDto(user.Id, user.FullName, user.Email ?? ""),
            ToFirmDto(firm));
    }

    private static FirmDto ToFirmDto(Firm f) => new(
        f.Id, f.Name, f.OwnerName, f.Email, f.Phone, f.Timezone,
        f.Plan.ToString(), f.ReminderMondayEnabled, f.ReminderThursdayEnabled, f.ReminderTimeOfDay);
}
