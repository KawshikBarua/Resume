using Microsoft.EntityFrameworkCore;
using SubChase.Application.Activities;
using SubChase.Application.Common;
using SubChase.Domain.Entities;
using SubChase.Domain.Exceptions;
using SubChase.Infrastructure.Data;

namespace SubChase.Infrastructure.Services;

public class ActivityService : IActivityService
{
    private readonly AppDbContext _db;
    private readonly ICurrentUser _current;

    public ActivityService(AppDbContext db, ICurrentUser current)
    {
        _db = db; _current = current;
    }

    private Guid FirmId => _current.FirmId ?? throw new ForbiddenException();

    public async Task<PagedResult<ActivityDto>> SearchAsync(int page, int pageSize, CancellationToken ct)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);

        var q = _db.Activities.AsNoTracking()
            .Where(a => a.FirmId == FirmId)
            .Include(a => a.Client)
            .OrderByDescending(a => a.CreatedAt);

        var total = await q.CountAsync(ct);
        var rows = await q.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);

        return new PagedResult<ActivityDto>
        {
            Items = rows.Select(ToDto).ToList(),
            Total = total, Page = page, PageSize = pageSize,
        };
    }

    public async Task<IReadOnlyList<ActivityDto>> GetRecentAsync(int limit, CancellationToken ct)
    {
        limit = Math.Clamp(limit, 1, 50);
        var rows = await _db.Activities.AsNoTracking()
            .Where(a => a.FirmId == FirmId)
            .Include(a => a.Client)
            .OrderByDescending(a => a.CreatedAt)
            .Take(limit)
            .ToListAsync(ct);
        return rows.Select(ToDto).ToList();
    }

    private static ActivityDto ToDto(Activity a) => new(
        a.Id, a.Type.ToString(), a.Message,
        a.ClientId, a.Client?.BusinessName, a.Client?.AvatarColor,
        a.DocumentRequestId, a.CreatedAt);
}
