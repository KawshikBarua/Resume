using Microsoft.EntityFrameworkCore;
using SubChase.Application.Documents;
using SubChase.Application.Portal;
using SubChase.Domain.Entities;
using SubChase.Domain.Enums;
using SubChase.Domain.Exceptions;
using SubChase.Infrastructure.Data;

namespace SubChase.Infrastructure.Services;

public class PortalService : IPortalService
{
    private readonly AppDbContext _db;
    public PortalService(AppDbContext db) { _db = db; }

    private async Task<Client> ResolveClientAsync(string token, CancellationToken ct)
    {
        var c = await _db.Clients
            .Include(x => x.Firm)
            .FirstOrDefaultAsync(x => x.PortalToken == token && x.Status == ClientStatus.Active, ct);
        if (c is null) throw new NotFoundException("PortalToken", token);
        return c;
    }

    public async Task<PortalContextDto> GetContextAsync(string portalToken, CancellationToken ct)
    {
        var client = await ResolveClientAsync(portalToken, ct);
        var period = CurrentPeriod();

        var reqs = await _db.DocumentRequests
            .Include(r => r.StoredFile)
            .AsNoTracking()
            .Where(r => r.ClientId == client.Id && r.Period == period && !r.Archived)
            .OrderBy(r => r.Status)
            .ThenBy(r => r.Label)
            .ToListAsync(ct);

        var pending = reqs.Where(r => r.Status == DocumentRequestStatus.Requested).Select(ToDto).ToList();
        var complete = reqs.Where(r => r.Status != DocumentRequestStatus.Requested).Select(ToDto).ToList();

        return new PortalContextDto(
            client.Id, client.BusinessName, client.ContactName,
            client.Firm.Name, client.Firm.OwnerName,
            period, pending, complete);
    }

    public async Task<DocumentRequestDto> UploadAsync(
        string portalToken, Guid requestId,
        string fileName, string contentType, Stream content, long size, CancellationToken ct)
    {
        var client = await ResolveClientAsync(portalToken, ct);

        var r = await _db.DocumentRequests
            .Include(x => x.Client)
            .FirstOrDefaultAsync(x => x.Id == requestId && x.ClientId == client.Id, ct)
            ?? throw new NotFoundException("DocumentRequest", requestId);

        await using var ms = new MemoryStream();
        await content.CopyToAsync(ms, ct);

        var sf = new StoredFile
        {
            FileName = fileName,
            ContentType = contentType,
            FileSize = size,
            Content = ms.ToArray(),
            UploadedByFirmId = client.FirmId,
            UploadedByUserId = null, // anonymous portal upload
        };
        _db.StoredFiles.Add(sf);

        r.StoredFile = sf;
        r.StoredFileId = sf.Id;
        r.Status = DocumentRequestStatus.Received;
        r.UploadedAt = DateTime.UtcNow;

        _db.Activities.Add(new Activity
        {
            FirmId = client.FirmId,
            ClientId = client.Id,
            DocumentRequestId = r.Id,
            Type = ActivityType.DocumentUploaded,
            Message = $"{client.BusinessName} uploaded {r.Label} via portal",
        });

        await _db.SaveChangesAsync(ct);

        var overdue = r.Status == DocumentRequestStatus.Requested &&
                      r.RequestedAt < DateTime.UtcNow.AddDays(-14);
        return new DocumentRequestDto(
            r.Id, r.ClientId, client.BusinessName, client.AvatarColor,
            r.Period, r.Label, r.DocumentTypeName, r.Required,
            r.Status.ToString(), r.RequestedAt, r.UploadedAt, r.ReviewedAt,
            r.ReviewerComment, r.Archived, sf.FileName, sf.FileSize, sf.ContentType, overdue);
    }

    private static string CurrentPeriod() => DateTime.UtcNow.ToString("MMM yyyy");

    private static PortalRequestDto ToDto(DocumentRequest r) => new(
        r.Id, r.Label, r.DocumentTypeName, r.Required, r.Status.ToString(),
        r.RequestedAt, r.UploadedAt, r.StoredFile?.FileName);
}
