using FluentValidation;
using Microsoft.EntityFrameworkCore;
using SubChase.Application.Clients;
using SubChase.Application.Common;
using SubChase.Domain.Entities;
using SubChase.Domain.Enums;
using SubChase.Domain.Exceptions;
using SubChase.Infrastructure.Data;

namespace SubChase.Infrastructure.Services;

public class ClientService : IClientService
{
    private readonly AppDbContext _db;
    private readonly ICurrentUser _current;
    private readonly IValidator<CreateClientRequest> _createValidator;
    private readonly IValidator<UpdateClientRequest> _updateValidator;

    private static readonly string[] AvatarPalette =
    {
        "#b8895f", "#9b6f47", "#6b8068", "#a8523d", "#c89b3f", "#2a3142"
    };

    public ClientService(
        AppDbContext db,
        ICurrentUser current,
        IValidator<CreateClientRequest> createValidator,
        IValidator<UpdateClientRequest> updateValidator)
    {
        _db = db;
        _current = current;
        _createValidator = createValidator;
        _updateValidator = updateValidator;
    }

    private Guid FirmId =>
        _current.FirmId ?? throw new ForbiddenException();

    public async Task<PagedResult<ClientProgressDto>> SearchAsync(
        string? search, string? sort, int page, int pageSize, CancellationToken ct)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);

        var query = _db.Clients.AsNoTracking()
            .Where(c => c.FirmId == FirmId && c.Status == ClientStatus.Active);

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.ToLower();
            query = query.Where(c =>
                c.BusinessName.ToLower().Contains(s) ||
                c.ContactName.ToLower().Contains(s) ||
                c.ContactEmail.ToLower().Contains(s));
        }

        var period = CurrentPeriod();

        var rows = await query.Select(c => new
        {
            c.Id, c.BusinessName, c.Industry, c.ContactName, c.ContactEmail, c.AvatarColor,
            Total = c.Requests.Count(r => r.Period == period && !r.Archived),
            Received = c.Requests.Count(r => r.Period == period && !r.Archived &&
                (r.Status == DocumentRequestStatus.Received || r.Status == DocumentRequestStatus.Reviewed)),
            LastUpload = c.Requests
                .Where(r => r.UploadedAt != null)
                .OrderByDescending(r => r.UploadedAt)
                .Select(r => (DateTime?)r.UploadedAt)
                .FirstOrDefault(),
            HasOverdue = c.Requests.Any(r =>
                r.Period == period &&
                r.Status == DocumentRequestStatus.Requested &&
                r.RequestedAt < DateTime.UtcNow.AddDays(-14))
        }).ToListAsync(ct);

        var mapped = rows.Select(r => new ClientProgressDto(
            r.Id, r.BusinessName, r.Industry, r.ContactName, r.ContactEmail, r.AvatarColor,
            r.Total, r.Received, r.LastUpload, r.HasOverdue));

        // In-memory sort (small N expected)
        mapped = (sort ?? "stalest") switch
        {
            "name" => mapped.OrderBy(c => c.BusinessName),
            "recent" => mapped.OrderByDescending(c => c.LastUpload ?? DateTime.MinValue),
            _ => mapped
                .OrderByDescending(c => c.Overdue)
                .ThenBy(c => c.LastUpload ?? DateTime.MinValue)
        };

        var list = mapped.ToList();
        var total = list.Count;
        var items = list.Skip((page - 1) * pageSize).Take(pageSize).ToList();

        return new PagedResult<ClientProgressDto> { Items = items, Total = total, Page = page, PageSize = pageSize };
    }

    public async Task<ClientDto> GetAsync(Guid id, CancellationToken ct)
    {
        var c = await _db.Clients.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", id);
        return ToDto(c);
    }

    public async Task<ClientDto> CreateAsync(CreateClientRequest req, CancellationToken ct)
    {
        await _createValidator.ValidateAndThrowAsync(req, ct);

        var c = new Client
        {
            FirmId = FirmId,
            BusinessName = req.BusinessName,
            Industry = req.Industry,
            ContactName = req.ContactName,
            ContactEmail = req.ContactEmail,
            ContactPhone = req.ContactPhone,
            Notes = req.Notes,
            AvatarColor = AvatarPalette[Random.Shared.Next(AvatarPalette.Length)],
        };
        _db.Clients.Add(c);
        _db.Activities.Add(new Activity
        {
            FirmId = FirmId,
            ClientId = c.Id,
            ActorUserId = _current.UserId,
            Type = ActivityType.ClientAdded,
            Message = $"Added client {c.BusinessName}",
        });
        await _db.SaveChangesAsync(ct);
        return ToDto(c);
    }

    public async Task<ClientDto> UpdateAsync(Guid id, UpdateClientRequest req, CancellationToken ct)
    {
        await _updateValidator.ValidateAndThrowAsync(req, ct);

        var c = await _db.Clients.FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", id);

        c.BusinessName = req.BusinessName;
        c.Industry = req.Industry;
        c.ContactName = req.ContactName;
        c.ContactEmail = req.ContactEmail;
        c.ContactPhone = req.ContactPhone;
        c.Notes = req.Notes;

        await _db.SaveChangesAsync(ct);
        return ToDto(c);
    }

    public async Task ArchiveAsync(Guid id, CancellationToken ct)
    {
        var c = await _db.Clients.FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", id);
        c.Status = ClientStatus.Archived;
        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = c.Id, ActorUserId = _current.UserId,
            Type = ActivityType.ClientArchived, Message = $"Archived {c.BusinessName}",
        });
        await _db.SaveChangesAsync(ct);
    }

    public async Task RestoreAsync(Guid id, CancellationToken ct)
    {
        var c = await _db.Clients.FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", id);
        c.Status = ClientStatus.Active;
        await _db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        var c = await _db.Clients.FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", id);
        _db.Clients.Remove(c);
        await _db.SaveChangesAsync(ct);
    }

    public async Task SendReminderAsync(Guid id, CancellationToken ct)
    {
        var c = await _db.Clients.FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", id);

        // Real implementation would queue an email via SMTP/SendGrid here.
        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = c.Id, ActorUserId = _current.UserId,
            Type = ActivityType.ReminderSent,
            Message = $"Reminder sent to {c.BusinessName}",
        });
        await _db.SaveChangesAsync(ct);
    }

    private static ClientDto ToDto(Client c) => new(
        c.Id, c.BusinessName, c.Industry, c.ContactName, c.ContactEmail,
        c.ContactPhone, c.Notes, c.Status.ToString(), c.AvatarColor,
        c.PortalToken, c.CreatedAt, c.UpdatedAt);

    private static string CurrentPeriod() => DateTime.UtcNow.ToString("MMM yyyy");
}
