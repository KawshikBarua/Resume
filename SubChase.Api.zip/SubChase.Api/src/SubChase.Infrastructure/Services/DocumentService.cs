using FluentValidation;
using Microsoft.EntityFrameworkCore;
using SubChase.Application.Common;
using SubChase.Application.Documents;
using SubChase.Domain.Entities;
using SubChase.Domain.Enums;
using SubChase.Domain.Exceptions;
using SubChase.Infrastructure.Data;

namespace SubChase.Infrastructure.Services;

public class DocumentService : IDocumentService
{
    private readonly AppDbContext _db;
    private readonly ICurrentUser _current;
    private readonly IValidator<CreateDocumentRequestRequest> _createValidator;
    private readonly IValidator<AddCommentRequest> _commentValidator;

    public DocumentService(
        AppDbContext db,
        ICurrentUser current,
        IValidator<CreateDocumentRequestRequest> createValidator,
        IValidator<AddCommentRequest> commentValidator)
    {
        _db = db;
        _current = current;
        _createValidator = createValidator;
        _commentValidator = commentValidator;
    }

    private Guid FirmId => _current.FirmId ?? throw new ForbiddenException();

    // Query that filters to current firm by joining through Client
    private IQueryable<DocumentRequest> FirmRequests() =>
        _db.DocumentRequests.Where(r => r.Client.FirmId == FirmId);

    public async Task<PagedResult<DocumentRequestDto>> SearchAsync(
        string? search, string? status, string? period, Guid? clientId,
        int page, int pageSize, CancellationToken ct)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);

        var q = FirmRequests().Include(r => r.Client).Include(r => r.StoredFile).AsNoTracking();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.ToLower();
            q = q.Where(r =>
                r.Label.ToLower().Contains(s) ||
                r.Client.BusinessName.ToLower().Contains(s) ||
                (r.StoredFile != null && r.StoredFile.FileName.ToLower().Contains(s)));
        }
        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<DocumentRequestStatus>(status, true, out var st))
            q = q.Where(r => r.Status == st);
        if (!string.IsNullOrWhiteSpace(period))
            q = q.Where(r => r.Period == period);
        if (clientId is not null)
            q = q.Where(r => r.ClientId == clientId);

        var total = await q.CountAsync(ct);

        var rows = await q
            .OrderByDescending(r => r.Status == DocumentRequestStatus.Requested)
            .ThenByDescending(r => r.UploadedAt ?? r.RequestedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return new PagedResult<DocumentRequestDto>
        {
            Items = rows.Select(ToDto).ToList(),
            Total = total, Page = page, PageSize = pageSize,
        };
    }

    public async Task<DocumentRequestDto> GetAsync(Guid id, CancellationToken ct)
    {
        var r = await FirmRequests()
            .Include(x => x.Client)
            .Include(x => x.StoredFile)
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id, ct)
            ?? throw new NotFoundException("DocumentRequest", id);
        return ToDto(r);
    }

    public async Task<DocumentRequestDto> CreateAsync(CreateDocumentRequestRequest req, CancellationToken ct)
    {
        await _createValidator.ValidateAndThrowAsync(req, ct);

        var client = await _db.Clients.FirstOrDefaultAsync(c => c.Id == req.ClientId && c.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", req.ClientId);

        var r = new DocumentRequest
        {
            ClientId = client.Id,
            Period = req.Period,
            Label = req.Label,
            DocumentTypeName = req.DocumentTypeName,
            Required = req.Required,
            Status = DocumentRequestStatus.Requested,
            RequestedAt = DateTime.UtcNow,
        };
        _db.DocumentRequests.Add(r);

        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = client.Id, DocumentRequestId = r.Id,
            ActorUserId = _current.UserId,
            Type = ActivityType.DocumentRequested,
            Message = $"Requested \"{r.Label}\" from {client.BusinessName}",
        });

        await _db.SaveChangesAsync(ct);

        var withClient = await FirmRequests().Include(x => x.Client).Include(x => x.StoredFile)
            .FirstAsync(x => x.Id == r.Id, ct);
        return ToDto(withClient);
    }

    public async Task<DocumentRequestDto> UploadFileAsync(
        Guid requestId, string fileName, string contentType, Stream content, long size, CancellationToken ct)
    {
        var r = await FirmRequests().Include(x => x.Client).FirstOrDefaultAsync(x => x.Id == requestId, ct)
            ?? throw new NotFoundException("DocumentRequest", requestId);

        var bytes = await ReadAllAsync(content, ct);

        var sf = new StoredFile
        {
            FileName = fileName,
            ContentType = contentType,
            FileSize = size,
            Content = bytes,
            UploadedByFirmId = FirmId,
            UploadedByUserId = _current.UserId,
        };
        _db.StoredFiles.Add(sf);

        r.StoredFile = sf;
        r.StoredFileId = sf.Id;
        r.Status = DocumentRequestStatus.Received;
        r.UploadedAt = DateTime.UtcNow;

        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = r.ClientId, DocumentRequestId = r.Id,
            ActorUserId = _current.UserId,
            Type = ActivityType.DocumentUploaded,
            Message = $"{r.Client.BusinessName} uploaded {r.Label}",
        });

        await _db.SaveChangesAsync(ct);
        return await GetAsync(r.Id, ct);
    }

    public async Task<(byte[] Bytes, string ContentType, string FileName)> DownloadFileAsync(
        Guid requestId, CancellationToken ct)
    {
        var r = await FirmRequests().Include(x => x.StoredFile)
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == requestId, ct)
            ?? throw new NotFoundException("DocumentRequest", requestId);

        if (r.StoredFile is null)
            throw new NotFoundException("File", requestId);

        return (r.StoredFile.Content, r.StoredFile.ContentType, r.StoredFile.FileName);
    }

    public async Task<DocumentRequestDto> MarkReviewedAsync(Guid id, CancellationToken ct)
    {
        var r = await FirmRequests().Include(x => x.Client).FirstOrDefaultAsync(x => x.Id == id, ct)
            ?? throw new NotFoundException("DocumentRequest", id);

        if (r.Status != DocumentRequestStatus.Received)
            throw new DomainException("Only received documents can be marked reviewed.");

        r.Status = DocumentRequestStatus.Reviewed;
        r.ReviewedAt = DateTime.UtcNow;

        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = r.ClientId, DocumentRequestId = r.Id,
            ActorUserId = _current.UserId,
            Type = ActivityType.DocumentReviewed,
            Message = $"Reviewed {r.Label} from {r.Client.BusinessName}",
        });

        await _db.SaveChangesAsync(ct);
        return await GetAsync(r.Id, ct);
    }

    public async Task<DocumentRequestDto> RerequestAsync(Guid id, CancellationToken ct)
    {
        var r = await FirmRequests().Include(x => x.Client).FirstOrDefaultAsync(x => x.Id == id, ct)
            ?? throw new NotFoundException("DocumentRequest", id);

        r.Status = DocumentRequestStatus.Requested;
        r.RequestedAt = DateTime.UtcNow;
        r.UploadedAt = null;
        r.ReviewedAt = null;
        r.StoredFile = null;
        r.StoredFileId = null; // detach but keep StoredFile row for history

        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = r.ClientId, DocumentRequestId = r.Id,
            ActorUserId = _current.UserId,
            Type = ActivityType.DocumentRerequested,
            Message = $"Re-requested {r.Label} from {r.Client.BusinessName}",
        });

        await _db.SaveChangesAsync(ct);
        return await GetAsync(r.Id, ct);
    }

    public async Task<DocumentRequestDto> AddCommentAsync(Guid id, AddCommentRequest req, CancellationToken ct)
    {
        await _commentValidator.ValidateAndThrowAsync(req, ct);

        var r = await FirmRequests().Include(x => x.Client).FirstOrDefaultAsync(x => x.Id == id, ct)
            ?? throw new NotFoundException("DocumentRequest", id);

        r.ReviewerComment = req.Comment;

        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = r.ClientId, DocumentRequestId = r.Id,
            ActorUserId = _current.UserId,
            Type = ActivityType.CommentAdded,
            Message = $"Note added on {r.Label}",
        });

        await _db.SaveChangesAsync(ct);
        return await GetAsync(r.Id, ct);
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        var r = await FirmRequests().FirstOrDefaultAsync(x => x.Id == id, ct)
            ?? throw new NotFoundException("DocumentRequest", id);
        _db.DocumentRequests.Remove(r);
        await _db.SaveChangesAsync(ct);
    }

    public async Task<OverallStatsDto> GetOverallStatsAsync(CancellationToken ct)
    {
        var period = CurrentPeriod();

        var q = FirmRequests().Where(r => !r.Archived && r.Period == period);

        var total = await q.CountAsync(ct);
        var received = await q.CountAsync(r =>
            r.Status == DocumentRequestStatus.Received || r.Status == DocumentRequestStatus.Reviewed, ct);
        var reviewed = await q.CountAsync(r => r.Status == DocumentRequestStatus.Reviewed, ct);
        var pending = await q.CountAsync(r => r.Status == DocumentRequestStatus.Requested, ct);
        var overdue = await q.CountAsync(r =>
            r.Status == DocumentRequestStatus.Requested &&
            r.RequestedAt < DateTime.UtcNow.AddDays(-14), ct);

        var clientsCount = await _db.Clients
            .CountAsync(c => c.FirmId == FirmId && c.Status == ClientStatus.Active, ct);

        return new OverallStatsDto(total, received, reviewed, pending, overdue, clientsCount);
    }

    public async Task<IReadOnlyList<DocumentRequestDto>> GetCurrentMonthForClientAsync(
        Guid clientId, CancellationToken ct)
    {
        var period = CurrentPeriod();
        var list = await FirmRequests()
            .Include(r => r.Client).Include(r => r.StoredFile)
            .AsNoTracking()
            .Where(r => r.ClientId == clientId && r.Period == period)
            .OrderBy(r => r.Status)
            .ThenByDescending(r => r.UploadedAt ?? r.RequestedAt)
            .ToListAsync(ct);
        return list.Select(ToDto).ToList();
    }

    private static DocumentRequestDto ToDto(DocumentRequest r)
    {
        var overdue = r.Status == DocumentRequestStatus.Requested &&
                      r.RequestedAt < DateTime.UtcNow.AddDays(-14);
        return new DocumentRequestDto(
            r.Id, r.ClientId, r.Client.BusinessName, r.Client.AvatarColor,
            r.Period, r.Label, r.DocumentTypeName, r.Required,
            r.Status.ToString(), r.RequestedAt, r.UploadedAt, r.ReviewedAt,
            r.ReviewerComment, r.Archived,
            r.StoredFile?.FileName, r.StoredFile?.FileSize, r.StoredFile?.ContentType,
            overdue);
    }

    private static string CurrentPeriod() => DateTime.UtcNow.ToString("MMM yyyy");

    private static async Task<byte[]> ReadAllAsync(Stream s, CancellationToken ct)
    {
        await using var ms = new MemoryStream();
        await s.CopyToAsync(ms, ct);
        return ms.ToArray();
    }
}
