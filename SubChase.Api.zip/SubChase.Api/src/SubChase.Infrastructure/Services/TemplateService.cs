using FluentValidation;
using Microsoft.EntityFrameworkCore;
using SubChase.Application.Common;
using SubChase.Application.Templates;
using SubChase.Domain.Entities;
using SubChase.Domain.Enums;
using SubChase.Domain.Exceptions;
using SubChase.Infrastructure.Data;

namespace SubChase.Infrastructure.Services;

public class TemplateService : ITemplateService
{
    private readonly AppDbContext _db;
    private readonly ICurrentUser _current;
    private readonly IValidator<CreateTemplateRequest> _createValidator;
    private readonly IValidator<UpdateTemplateRequest> _updateValidator;

    public TemplateService(
        AppDbContext db,
        ICurrentUser current,
        IValidator<CreateTemplateRequest> createValidator,
        IValidator<UpdateTemplateRequest> updateValidator)
    {
        _db = db;
        _current = current;
        _createValidator = createValidator;
        _updateValidator = updateValidator;
    }

    private Guid FirmId => _current.FirmId ?? throw new ForbiddenException();

    public async Task<IReadOnlyList<TemplateDto>> ListAsync(CancellationToken ct)
    {
        var list = await _db.Templates.AsNoTracking()
            .Where(t => t.FirmId == FirmId)
            .Include(t => t.Items.OrderBy(i => i.Order))
            .OrderBy(t => t.Name)
            .ToListAsync(ct);

        return list.Select(ToDto).ToList();
    }

    public async Task<TemplateDto> GetAsync(Guid id, CancellationToken ct)
    {
        var t = await _db.Templates.AsNoTracking()
            .Include(x => x.Items.OrderBy(i => i.Order))
            .FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Template", id);
        return ToDto(t);
    }

    public async Task<TemplateDto> CreateAsync(CreateTemplateRequest req, CancellationToken ct)
    {
        await _createValidator.ValidateAndThrowAsync(req, ct);

        var t = new DocumentTemplate
        {
            FirmId = FirmId,
            Name = req.Name,
            Description = req.Description,
            Cadence = req.Cadence,
            Items = req.Items.Select((i, idx) => new DocumentTemplateItem
            {
                Label = i.Label,
                Description = i.Description,
                Required = i.Required,
                Order = idx,
            }).ToList(),
        };
        _db.Templates.Add(t);
        await _db.SaveChangesAsync(ct);
        return ToDto(t);
    }

    public async Task<TemplateDto> UpdateAsync(Guid id, UpdateTemplateRequest req, CancellationToken ct)
    {
        await _updateValidator.ValidateAndThrowAsync(req, ct);

        var t = await _db.Templates.Include(x => x.Items)
            .FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Template", id);

        t.Name = req.Name;
        t.Description = req.Description;
        t.Cadence = req.Cadence;

        // Replace items (simple strategy)
        _db.TemplateItems.RemoveRange(t.Items);
        t.Items = req.Items.Select((i, idx) => new DocumentTemplateItem
        {
            TemplateId = t.Id,
            Label = i.Label,
            Description = i.Description,
            Required = i.Required,
            Order = idx,
        }).ToList();

        await _db.SaveChangesAsync(ct);
        return ToDto(t);
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        var t = await _db.Templates.FirstOrDefaultAsync(x => x.Id == id && x.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Template", id);
        _db.Templates.Remove(t);
        await _db.SaveChangesAsync(ct);
    }

    public async Task<int> ApplyAsync(ApplyTemplateRequest req, CancellationToken ct)
    {
        var template = await _db.Templates.AsNoTracking()
            .Include(t => t.Items)
            .FirstOrDefaultAsync(t => t.Id == req.TemplateId && t.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Template", req.TemplateId);

        var client = await _db.Clients
            .FirstOrDefaultAsync(c => c.Id == req.ClientId && c.FirmId == FirmId, ct)
            ?? throw new NotFoundException("Client", req.ClientId);

        var created = 0;
        foreach (var item in template.Items.OrderBy(i => i.Order))
        {
            // Skip if a request for this label/period already exists
            var exists = await _db.DocumentRequests.AnyAsync(r =>
                r.ClientId == client.Id && r.Period == req.Period && r.Label == item.Label, ct);
            if (exists) continue;

            _db.DocumentRequests.Add(new DocumentRequest
            {
                ClientId = client.Id,
                Period = req.Period,
                Label = item.Label,
                DocumentTypeName = item.Description,
                Required = item.Required,
                Status = DocumentRequestStatus.Requested,
                RequestedAt = DateTime.UtcNow,
            });
            created++;
        }

        _db.Activities.Add(new Activity
        {
            FirmId = FirmId, ClientId = client.Id, ActorUserId = _current.UserId,
            Type = ActivityType.TemplateApplied,
            Message = $"Applied template \"{template.Name}\" to {client.BusinessName} for {req.Period} ({created} items)",
        });

        await _db.SaveChangesAsync(ct);
        return created;
    }

    private static TemplateDto ToDto(DocumentTemplate t) => new(
        t.Id, t.Name, t.Description, t.Cadence,
        t.Items.OrderBy(i => i.Order)
            .Select(i => new TemplateItemDto(i.Id, i.Label, i.Description, i.Required, i.Order))
            .ToList(),
        t.CreatedAt);
}
