using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using SubChase.Application.Activities;
using SubChase.Application.Auth;
using SubChase.Application.Clients;
using SubChase.Application.Documents;
using SubChase.Application.Portal;
using SubChase.Application.Templates;
using SubChase.Domain.Entities;
using SubChase.Infrastructure.Auth;
using SubChase.Infrastructure.Data;
using SubChase.Infrastructure.Services;
using System.Text;

namespace SubChase.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services, IConfiguration config)
    {
        // Database
        var connStr = config.GetConnectionString("Postgres")
            ?? throw new InvalidOperationException("Missing 'Postgres' connection string.");
        services.AddDbContext<AppDbContext>(opt => opt.UseNpgsql(connStr));

        // Identity
        services.AddIdentityCore<AppUser>(o =>
            {
                o.Password.RequireDigit = false;
                o.Password.RequireUppercase = false;
                o.Password.RequireNonAlphanumeric = false;
                o.Password.RequiredLength = 8;
                o.User.RequireUniqueEmail = true;
            })
            .AddRoles<IdentityRole<Guid>>()
            .AddEntityFrameworkStores<AppDbContext>()
            .AddSignInManager();

        // JWT
        var jwtOptions = new JwtOptions();
        config.GetSection("Jwt").Bind(jwtOptions);
        services.AddSingleton(jwtOptions);
        services.AddSingleton<IJwtTokenGenerator, JwtTokenGenerator>();

        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = jwtOptions.Issuer,
                    ValidAudience = jwtOptions.Audience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtOptions.SigningKey)),
                };
            });

        services.AddAuthorization();

        // Application services
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<IClientService, ClientService>();
        services.AddScoped<ITemplateService, TemplateService>();
        services.AddScoped<IDocumentService, DocumentService>();
        services.AddScoped<IActivityService, ActivityService>();
        services.AddScoped<IPortalService, PortalService>();

        return services;
    }
}
