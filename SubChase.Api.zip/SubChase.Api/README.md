# SubChase API

ASP.NET Core 8 Web API backing the SubChase document-collection app. PostgreSQL for storage (including uploaded files as `bytea`), ASP.NET Core Identity for users, JWT bearer tokens for auth.

## Stack

- .NET 8 / ASP.NET Core
- EF Core 8 with Npgsql
- ASP.NET Core Identity + JWT
- FluentValidation
- Serilog
- Swagger / OpenAPI

## Project layout

```
SubChase.sln
src/
├── SubChase.Domain/          Entities, enums, domain exceptions
├── SubChase.Application/     DTOs, service interfaces, validators
├── SubChase.Infrastructure/  EF Core DbContext, EF configurations,
│                              JWT generator, all service implementations
└── SubChase.Api/             Controllers, middleware, Program.cs
docker-compose.yml             Postgres + pgAdmin for local dev
Dockerfile                     Builds and runs the API
```

## Running locally

### 1. Start Postgres

```bash
docker compose up -d postgres
```

Postgres listens on `localhost:5432`. Credentials are `subchase / subchase / subchase` (db / user / password). Optional pgAdmin is exposed on `http://localhost:5433` (login `admin@subchase.local` / `admin`).

### 2. Create the initial EF migration (one-time)

The project ships without a migration so you can name your own baseline:

```bash
cd src/SubChase.Api
dotnet tool install --global dotnet-ef    # if not already
dotnet ef migrations add Initial -p ../SubChase.Infrastructure -s .
```

(`-p` points to the project owning the DbContext; `-s` is the startup project the EF tool runs to resolve config.)

### 3. Run the API

```bash
dotnet run --project src/SubChase.Api
```

Defaults:

- API: `http://localhost:5050`
- Swagger UI: `http://localhost:5050/swagger`

On first start the API:

1. Runs migrations against the Postgres database.
2. Seeds a demo firm + user so you can log in immediately.

**Demo credentials:** `demo@subchase.app` / `demo1234`

### 4. (Optional) Run everything in Docker

After creating the migration above:

```bash
docker compose up --build
```

(You'll need to add an `api` service to `docker-compose.yml` pointing at the included `Dockerfile`. It's left out by default so you can iterate against your host's `dotnet run` without rebuilding the image.)

## API surface

All routes are under `/api`. Authenticated routes need `Authorization: Bearer <jwt>` from the login/register response.

### Auth (public)

| Method | Route                 | Body                          |
|--------|-----------------------|-------------------------------|
| POST   | `/api/auth/register`  | `RegisterRequest`             |
| POST   | `/api/auth/login`     | `LoginRequest`                |
| GET    | `/api/auth/me`        | —                             |
| PUT    | `/api/auth/firm`      | `UpdateFirmRequest`           |

### Clients

| Method | Route                                  | Notes                              |
|--------|----------------------------------------|------------------------------------|
| GET    | `/api/clients`                         | `?search=&sort=stalest&page=&pageSize=` |
| GET    | `/api/clients/{id}`                    |                                    |
| GET    | `/api/clients/{id}/requests/current`   | Current-period requests for client |
| POST   | `/api/clients`                         |                                    |
| PUT    | `/api/clients/{id}`                    |                                    |
| POST   | `/api/clients/{id}/archive`            |                                    |
| POST   | `/api/clients/{id}/restore`            |                                    |
| POST   | `/api/clients/{id}/nudge`              | Logs a `ReminderSent` activity     |
| DELETE | `/api/clients/{id}`                    |                                    |

### Templates

| Method | Route                       | Notes                                              |
|--------|-----------------------------|----------------------------------------------------|
| GET    | `/api/templates`            |                                                    |
| GET    | `/api/templates/{id}`       |                                                    |
| POST   | `/api/templates`            |                                                    |
| PUT    | `/api/templates/{id}`       |                                                    |
| DELETE | `/api/templates/{id}`       |                                                    |
| POST   | `/api/templates/apply`      | `{ templateId, clientId, period }` → creates requests |

### Documents

| Method | Route                              | Notes                                                  |
|--------|------------------------------------|--------------------------------------------------------|
| GET    | `/api/documents`                   | `?search=&status=&period=&clientId=&page=&pageSize=`   |
| GET    | `/api/documents/stats`             | KPIs for current period                                |
| GET    | `/api/documents/{id}`              |                                                        |
| POST   | `/api/documents`                   | Create a single request                                |
| POST   | `/api/documents/{id}/upload`       | `multipart/form-data; file=...`                        |
| GET    | `/api/documents/{id}/download`     | Streams the file                                       |
| POST   | `/api/documents/{id}/review`       | Received → Reviewed                                    |
| POST   | `/api/documents/{id}/rerequest`    | Reset back to Requested, detach file (file kept)       |
| POST   | `/api/documents/{id}/comment`      | `{ comment }`                                          |
| DELETE | `/api/documents/{id}`              |                                                        |

### Activity

| Method | Route                  | Notes                |
|--------|------------------------|----------------------|
| GET    | `/api/activities`      | `?page=&pageSize=`   |
| GET    | `/api/activities/recent` | `?limit=10`        |

### Public client portal (no auth, token-gated)

The portal token is `Client.PortalToken` — an opaque 32-char identifier returned on `GET /api/clients/{id}`.

| Method | Route                                                       | Notes                          |
|--------|-------------------------------------------------------------|--------------------------------|
| GET    | `/api/portal/{token}`                                       | Returns the portal context     |
| POST   | `/api/portal/{token}/requests/{requestId}/upload`           | `multipart/form-data`          |

## Connecting the React frontend

The React app's stores (`authStore`, `clientStore`, `documentStore`, …) currently hold mock data. To wire them to this API:

1. Set `VITE_API_URL=http://localhost:5050` in `.env`.
2. Replace each store's local-state mutations with `fetch` (or axios) calls to the routes above.
3. After login/register, persist `AuthResponse.AccessToken` and send it as `Authorization: Bearer <token>` on every other request.

CORS is preconfigured for `http://localhost:5173`, `http://localhost:4173`, and `http://localhost:3000`.

## Design notes worth knowing

- **Multi-tenancy** is enforced at the service layer by scoping every query to `ICurrentUser.FirmId` (resolved from the JWT's `firm_id` claim). It is **not** enforced at the database level (no row-level security). Don't bypass the services.
- **File storage** uses Postgres `bytea`. Fine for typical accounting docs (PDFs, statements, receipts). For multi-MB-per-file workloads, swap `StoredFile.Content` for an `IFileStorage` abstraction backed by S3/MinIO.
- **Periods** are derived as `"MMM yyyy"` (`May 2026`) from UTC. Per-firm timezone-aware period boundaries are a follow-up.
- **Re-request** keeps the historical `StoredFile` row but unlinks it from the request, so prior uploads aren't lost.
- **Reminders** write to the activity log only — wire up SMTP/SendGrid via a future `IEmailSender`.
- **JWT signing key** in `appsettings.json` is a placeholder. For production, set it via environment variable (`Jwt__SigningKey`) or user-secrets.

## Common dev commands

```bash
# Add a new migration after changing entities
dotnet ef migrations add <Name> -p src/SubChase.Infrastructure -s src/SubChase.Api

# Apply migrations manually
dotnet ef database update -p src/SubChase.Infrastructure -s src/SubChase.Api

# Drop the database (careful!)
dotnet ef database drop -p src/SubChase.Infrastructure -s src/SubChase.Api -f

# Build
dotnet build SubChase.sln

# Run with hot reload
dotnet watch run --project src/SubChase.Api
```
