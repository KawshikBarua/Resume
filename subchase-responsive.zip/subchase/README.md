# SubChase

> Document collection on autopilot for bookkeepers and small CPA firms.

A working MVP frontend built with React, Vite, and Zustand. All data is client-side dummy data — no backend required to demo.

## Quick start

```bash
npm install
npm run dev
```

Open http://localhost:5173

## What's in the box

- **Dashboard** — at-a-glance KPIs, "today's chase list" sorted by stalest client, recent activity feed
- **Clients** — searchable, sortable roster with per-client month progress
- **Client detail** — current-period document checklist, archive of past periods, comments, re-request, mark-reviewed actions
- **Documents** — global search across every document request with filters
- **Templates** — reusable monthly/quarterly/annual document checklists; full template builder
- **Activity** — chronological audit trail grouped by day
- **Settings** — firm profile, email cadence preview, security overview, plan management
- **Login** — split editorial design with demo credentials (any email + password)
- **Client Portal** — the public, no-login upload view your clients see when they click their tokenized link

## Tech stack

- **Vite** + **React 18** (JavaScript, no TypeScript)
- **Zustand** for state management (six domain-split stores)
- **react-router-dom** v6
- **date-fns** for date formatting
- **lucide-react** for icons
- **Fraunces** (display serif) + **Inter** (body) + **JetBrains Mono** (mono) via Google Fonts

## Project structure

```
src/
├── App.jsx                  # Router + route definitions
├── main.jsx                 # Entry point
├── components/
│   ├── layout/              # AppShell, Sidebar, Topbar, ProtectedRoute
│   └── ui/                  # Button, Card, Input, Modal, Badge, Avatar, Progress, Toast, EmptyState
├── pages/                   # One file per route
├── store/                   # Zustand stores (auth, clients, documents, templates, activity, ui)
├── data/                    # dummyData.js — all seed data lives here
├── lib/                     # utils.js — date/format/id helpers
├── hooks/                   # (reserved for custom hooks)
└── styles/
    └── globals.css          # Design tokens + reset
```

## Design system

Editorial / refined — chosen to feel trustworthy and professional for a financial-services audience.

- **Palette**: warm paper (#faf8f4) backgrounds, deep ink (#1a1f2e) primary, hand-mixed accents in warm tan, sage, gold, and rust
- **Typography**: Fraunces serif for display + Inter for body. All headlines use optical-size 144 for maximum elegance at large sizes.
- **Components**: every UI primitive uses CSS variables for theming consistency

## Demo notes

- Logged in by default as Eleanor Whitmore of Whitmore & Co. Bookkeeping
- 8 seeded clients with realistic businesses (coffee roaster, construction, vet clinic, yoga studio, etc.)
- ~80 document requests spanning current and previous month with varied states
- Click any client → see their document checklist → click "Copy upload link" then visit `/portal/cli_001` to see the client-facing view
- All actions (mark reviewed, send reminder, add comment) work in real-time via Zustand
- Auth state persists via Zustand `persist` middleware → localStorage

## What's intentionally not built (per the MVP spec)

- QuickBooks/Xero integration
- Native mobile apps
- Team members & permissions
- Custom branding / white-label
- AI document extraction (deferred to v2)
- Real file storage / S3 / virus scanning
- Real email/SMS sending

These are all v2+ features. The MVP is intentionally tight to ship in 6–8 weeks.

## Next steps

1. Wire to a real backend (Postgres + Hono or Express works fine)
2. Add Stripe Checkout for billing
3. Add Resend/Postmark for email, Twilio for SMS
4. Implement tokenized client portal URLs server-side
5. Ship to the 5 pre-sold customers from the validation plan
