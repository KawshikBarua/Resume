import { Link } from 'react-router-dom';
import {
  ArrowUpRight,
  Send,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Inbox,
  TrendingUp,
} from 'lucide-react';
import {
  useClientStore,
  useDocumentStore,
  useActivityStore,
  useUIStore,
} from '@/store';
import { Card, CardBody, Badge, Progress, Avatar, Button } from '@/components/ui';
import { currentPeriod, timeAgo, daysSince } from '@/lib/utils';
import './Dashboard.css';

export function DashboardPage() {
  const clients = useClientStore((s) => s.getFilteredClients());
  const getCurrentMonthRequests = useDocumentStore((s) => s.getCurrentMonthRequests);
  const stats = useDocumentStore((s) => s.getOverallStats());
  const recentActivity = useActivityStore((s) => s.getRecent(6));
  const pushToast = useUIStore((s) => s.pushToast);

  const period = currentPeriod();
  const completionRate = stats.total > 0 ? Math.round((stats.received / stats.total) * 100) : 0;

  // Build per-client roll-up sorted by stalest
  const clientSummary = clients
    .map((client) => {
      const requests = getCurrentMonthRequests(client.id);
      const received = requests.filter(
        (r) => r.status === 'received' || r.status === 'reviewed'
      ).length;
      const lastUpload = requests
        .filter((r) => r.uploadedAt)
        .map((r) => new Date(r.uploadedAt))
        .sort((a, b) => b - a)[0];
      const overdue = requests.some(
        (r) => r.status === 'requested' && daysSince(r.requestedAt) > 14
      );
      return {
        client,
        total: requests.length,
        received,
        lastUpload,
        overdue,
        complete: requests.length > 0 && received === requests.length,
      };
    })
    .sort((a, b) => {
      // Stalest first: overdue, then by oldest last upload, then incomplete
      if (a.overdue !== b.overdue) return b.overdue - a.overdue;
      if (!a.lastUpload && b.lastUpload) return -1;
      if (a.lastUpload && !b.lastUpload) return 1;
      if (a.lastUpload && b.lastUpload) return a.lastUpload - b.lastUpload;
      return 0;
    });

  const handleNudge = (clientName) => {
    pushToast({
      title: 'Reminder sent',
      description: `${clientName} will receive a polite nudge in the next minute.`,
      variant: 'success',
    });
  };

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">{period}</div>
          <h1 className="page-title">Good morning, Eleanor.</h1>
          <p className="page-description">
            Here's what your books need attention on today. Stalest clients are at the top —
            chase them first.
          </p>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="kpi-grid">
        <Card className="kpi-card">
          <CardBody>
            <div className="kpi-icon kpi-icon-accent">
              <Inbox size={18} strokeWidth={1.7} />
            </div>
            <div className="kpi-value">{stats.total}</div>
            <div className="kpi-label">Documents requested</div>
            <div className="kpi-meta">across {clients.length} clients</div>
          </CardBody>
        </Card>

        <Card className="kpi-card">
          <CardBody>
            <div className="kpi-icon kpi-icon-success">
              <CheckCircle2 size={18} strokeWidth={1.7} />
            </div>
            <div className="kpi-value">{stats.received}</div>
            <div className="kpi-label">Collected this month</div>
            <div className="kpi-meta">
              <TrendingUp size={11} strokeWidth={2} />
              {completionRate}% complete
            </div>
          </CardBody>
        </Card>

        <Card className="kpi-card">
          <CardBody>
            <div className="kpi-icon kpi-icon-warning">
              <Clock size={18} strokeWidth={1.7} />
            </div>
            <div className="kpi-value">{stats.pending}</div>
            <div className="kpi-label">Still pending</div>
            <div className="kpi-meta">{stats.reviewed} reviewed</div>
          </CardBody>
        </Card>

        <Card className="kpi-card kpi-card-feature">
          <CardBody>
            <div className="kpi-feature-label">This week's pace</div>
            <div className="kpi-feature-value">
              <span className="serif">{Math.round(stats.received * 0.6)}</span>
              <span className="kpi-feature-unit">docs/week</span>
            </div>
            <Progress
              value={completionRate}
              total={100}
              variant={completionRate > 70 ? 'success' : completionRate > 40 ? 'accent' : 'warning'}
            />
            <div className="kpi-feature-caption">
              {completionRate > 70
                ? "You're ahead of schedule."
                : completionRate > 40
                ? 'On track for month-end.'
                : 'A few clients need nudging.'}
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Client roll-up */}
      <div className="dashboard-grid">
        <div className="section">
          <div className="section-header">
            <div>
              <h2 className="section-title">Today's chase list</h2>
              <p className="section-subtitle">Sorted by stalest first — these need attention.</p>
            </div>
            <Link to="/clients" className="section-link">
              See all clients <ArrowUpRight size={13} strokeWidth={1.8} />
            </Link>
          </div>

          <Card>
            <div className="chase-list">
              {clientSummary.slice(0, 6).map(({ client, total, received, lastUpload, overdue, complete }) => (
                <Link
                  key={client.id}
                  to={`/clients/${client.id}`}
                  className="chase-row"
                >
                  <Avatar name={client.businessName} color={client.avatarColor} size="md" />
                  <div className="chase-row-info">
                    <div className="chase-row-name">{client.businessName}</div>
                    <div className="chase-row-meta">
                      <span className="mono">{received}/{total}</span> · last upload{' '}
                      {lastUpload ? timeAgo(lastUpload) : 'never'}
                    </div>
                  </div>
                  <div className="chase-row-progress">
                    <Progress
                      value={received}
                      total={total}
                      variant={
                        complete ? 'success' : overdue ? 'danger' : received > 0 ? 'accent' : 'warning'
                      }
                    />
                  </div>
                  <div className="chase-row-status">
                    {complete ? (
                      <Badge variant="success" dot>Complete</Badge>
                    ) : overdue ? (
                      <Badge variant="danger" dot>Overdue</Badge>
                    ) : received === 0 ? (
                      <Badge variant="warning" dot>Not started</Badge>
                    ) : (
                      <Badge variant="accent" dot>In progress</Badge>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={Send}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNudge(client.businessName);
                    }}
                  >
                    Nudge
                  </Button>
                </Link>
              ))}
            </div>
          </Card>
        </div>

        <div className="section">
          <div className="section-header">
            <div>
              <h2 className="section-title">Recent activity</h2>
              <p className="section-subtitle">Uploads, reviews, and sent reminders.</p>
            </div>
          </div>

          <Card>
            <div className="activity-list">
              {recentActivity.map((activity) => (
                <ActivityRow key={activity.id} activity={activity} />
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function ActivityRow({ activity }) {
  const getClient = useClientStore((s) => s.getClient);
  const client = activity.clientId ? getClient(activity.clientId) : null;

  const iconMap = {
    upload: { icon: Inbox, color: 'var(--sage)' },
    review: { icon: CheckCircle2, color: 'var(--accent)' },
    reminder: { icon: Send, color: 'var(--gold)' },
    request: { icon: AlertTriangle, color: 'var(--ink-muted)' },
  };
  const { icon: Icon, color } = iconMap[activity.type] || iconMap.request;

  return (
    <div className="activity-row">
      <div className="activity-icon" style={{ color }}>
        <Icon size={14} strokeWidth={1.8} />
      </div>
      <div className="activity-content">
        <div className="activity-message">{activity.message}</div>
        <div className="activity-time">{timeAgo(activity.timestamp)}</div>
      </div>
      {client && (
        <Avatar name={client.businessName} color={client.avatarColor} size="xs" />
      )}
    </div>
  );
}
