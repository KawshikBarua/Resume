import { CheckCircle2, Send, Inbox, AlertTriangle, Filter } from 'lucide-react';
import { useState } from 'react';
import { useActivityStore, useClientStore } from '@/store';
import { Card, Avatar, Select, EmptyState } from '@/components/ui';
import { timeAgo, formatDate } from '@/lib/utils';
import './Activity.css';

const iconMap = {
  upload: { icon: Inbox, color: 'var(--sage)', label: 'Upload' },
  review: { icon: CheckCircle2, color: 'var(--accent)', label: 'Review' },
  reminder: { icon: Send, color: 'var(--gold)', label: 'Reminder' },
  request: { icon: AlertTriangle, color: 'var(--ink-muted)', label: 'Request' },
};

export function ActivityPage() {
  const activities = useActivityStore((s) => s.activities);
  const getClient = useClientStore((s) => s.getClient);
  const [filter, setFilter] = useState('all');

  const filtered = filter === 'all' ? activities : activities.filter((a) => a.type === filter);

  // Group by date
  const groups = filtered.reduce((acc, activity) => {
    const date = formatDate(activity.timestamp, 'EEEE, MMMM d');
    if (!acc[date]) acc[date] = [];
    acc[date].push(activity);
    return acc;
  }, {});

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">Audit trail</div>
          <h1 className="page-title">Activity</h1>
          <p className="page-description">
            Every upload, review, and reminder sent. Useful when clients ask "did you get my file?"
          </p>
        </div>
        <div className="page-actions">
          <Select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All activity</option>
            <option value="upload">Uploads only</option>
            <option value="review">Reviews only</option>
            <option value="reminder">Reminders sent</option>
            <option value="request">New requests</option>
          </Select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={AlertTriangle}
            title="No activity yet"
            description="Once your clients start uploading or you send reminders, you'll see them here."
          />
        </Card>
      ) : (
        <div className="activity-timeline">
          {Object.entries(groups).map(([date, items]) => (
            <div key={date} className="activity-group">
              <div className="activity-date-label">{date}</div>
              <Card>
                <div className="activity-feed">
                  {items.map((activity) => {
                    const client = activity.clientId ? getClient(activity.clientId) : null;
                    const { icon: Icon, color, label } = iconMap[activity.type] || iconMap.request;
                    return (
                      <div key={activity.id} className="activity-feed-row">
                        <div className="activity-feed-icon" style={{ color, background: `${color}1a` }}>
                          <Icon size={14} strokeWidth={1.8} />
                        </div>
                        <div className="activity-feed-content">
                          <div className="activity-feed-message">{activity.message}</div>
                          <div className="activity-feed-meta">
                            <span className="activity-feed-type">{label}</span>
                            <span>·</span>
                            <span>{timeAgo(activity.timestamp)}</span>
                          </div>
                        </div>
                        {client && (
                          <Avatar name={client.businessName} color={client.avatarColor} size="sm" />
                        )}
                      </div>
                    );
                  })}
                </div>
              </Card>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
