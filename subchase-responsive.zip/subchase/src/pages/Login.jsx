import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowRight, Sparkles } from 'lucide-react';
import { useAuthStore } from '@/store';
import { Button, Input } from '@/components/ui';
import './Login.css';

export function LoginPage() {
  const navigate = useNavigate();
  const login = useAuthStore((s) => s.login);
  const [email, setEmail] = useState('eleanor@whitmoreco.com');
  const [password, setPassword] = useState('demo123');

  const handleLogin = (e) => {
    e.preventDefault();
    const result = login(email, password);
    if (result.success) {
      navigate('/');
    }
  };

  return (
    <div className="login-page">
      <div className="login-grain" />
      <div className="login-container">
        <div className="login-left">
          <div className="login-brand">
            <svg width="34" height="34" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
              <rect width="32" height="32" rx="7" fill="var(--ink)" />
              <text
                x="16"
                y="22"
                fontFamily="Fraunces, Georgia, serif"
                fontSize="18"
                fontWeight="600"
                fill="var(--accent)"
                textAnchor="middle"
              >
                S
              </text>
            </svg>
            <div className="login-brand-name">SubChase</div>
          </div>

          <h1 className="login-headline">
            Stop chasing.
            <br />
            <span className="login-headline-italic">Start closing books.</span>
          </h1>

          <p className="login-sub">
            Document collection on autopilot for bookkeepers and small CPA firms.
            Your clients upload in two clicks. You stop sending follow-ups on Sunday nights.
          </p>

          <div className="login-features">
            <div className="login-feature">
              <Sparkles size={14} strokeWidth={1.8} />
              <span>Automatic reminders at day 7, 14, and 21</span>
            </div>
            <div className="login-feature">
              <Sparkles size={14} strokeWidth={1.8} />
              <span>One-click upload portal, no client login</span>
            </div>
            <div className="login-feature">
              <Sparkles size={14} strokeWidth={1.8} />
              <span>Recurring monthly checklists per client</span>
            </div>
          </div>

          <blockquote className="login-quote">
            "I used to lose two hours every Friday chasing receipts. SubChase
            gave me my weekends back."
            <cite>— Eleanor Whitmore, Whitmore & Co. Bookkeeping</cite>
          </blockquote>
        </div>

        <div className="login-right">
          <div className="login-card">
            <div className="login-card-header">
              <h2 className="login-card-title">Welcome back</h2>
              <p className="login-card-sub">Sign in to continue to your dashboard.</p>
            </div>

            <form onSubmit={handleLogin} className="login-form">
              <Input
                label="Email"
                icon={Mail}
                type="email"
                placeholder="you@firm.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <Input
                label="Password"
                icon={Lock}
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />

              <div className="login-options">
                <label className="login-checkbox">
                  <input type="checkbox" defaultChecked />
                  <span>Keep me signed in</span>
                </label>
                <a href="#" className="login-forgot">Forgot password?</a>
              </div>

              <Button type="submit" variant="primary" size="lg" icon={ArrowRight} className="login-submit">
                Sign in
              </Button>

              <div className="login-divider">
                <span>or</span>
              </div>

              <Button type="button" variant="secondary" size="lg" className="login-google">
                Continue with Google
              </Button>

              <div className="login-footer">
                Don't have an account? <a href="#" className="login-link">Start a free trial</a>
              </div>

              <div className="login-demo-hint">
                <strong>Demo:</strong> any email + password works.
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
