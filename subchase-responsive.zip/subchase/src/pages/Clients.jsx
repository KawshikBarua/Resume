import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus, Users, ArrowUpRight } from 'lucide-react';
import {
  useClientStore,
  useDocumentStore,
  useTemplateStore,
  useUIStore,
} from '@/store';
import {
  Card,
  Button,
  Input,
  Select,
  Avatar,
  Badge,
  Progress,
  Modal,
  EmptyState,
  Textarea,
} from '@/components/ui';
import { timeAgo, daysSince } from '@/lib/utils';
import './Clients.css';

export function ClientsPage() {
  const clients = useClientStore((s) => s.getFilteredClients());
  const searchQuery = useClientStore((s) => s.searchQuery);
  const setSearchQuery = useClientStore((s) => s.setSearchQuery);
  const sortBy = useClientStore((s) => s.sortBy);
  const setSortBy = useClientStore((s) => s.setSortBy);
  const addClient = useClientStore((s) => s.addClient);
  const templates = useTemplateStore((s) => s.templates);
  const getCurrentMonthRequests = useDocumentStore((s) => s.getCurrentMonthRequests);
  const pushToast = useUIStore((s) => s.pushToast);

  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    businessName: '',
    contactName: '',
    email: '',
    phone: '',
    industry: '',
    templateId: templates[0]?.id || '',
    notes: '',
  });

  const handleAdd = (e) => {
    e.preventDefault();
    if (!form.businessName || !form.email) return;
    addClient(form);
    pushToast({
      title: 'Client added',
      description: `${form.businessName} is now in your roster.`,
      variant: 'success',
    });
    setShowAdd(false);
    setForm({
      businessName: '',
      contactName: '',
      email: '',
      phone: '',
      industry: '',
      templateId: templates[0]?.id || '',
      notes: '',
    });
  };

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">Roster</div>
          <h1 className="page-title">Clients</h1>
          <p className="page-description">
            Every business whose books you keep. Click any to see their document status,
            send a reminder, or review uploads.
          </p>
        </div>
        <div className="page-actions">
          <Button variant="accent" icon={Plus} onClick={() => setShowAdd(true)}>
            Add client
          </Button>
        </div>
      </div>

      <Card className="clients-toolbar">
        <Input
          icon={Search}
          placeholder="Search by business, contact, or email…"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="clients-search"
        />
        <Select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="clients-sort"
        >
          <option value="staleness">Sort: Stalest first</option>
          <option value="name">Sort: A–Z</option>
          <option value="recent">Sort: Recently added</option>
        </Select>
      </Card>

      {clients.length === 0 ? (
        <Card>
          <EmptyState
            icon={Users}
            title={searchQuery ? 'No matching clients' : 'No clients yet'}
            description={
              searchQuery
                ? 'Try a different search term.'
                : 'Add your first client to start collecting their monthly documents automatically.'
            }
            action={
              !searchQuery && (
                <Button variant="accent" icon={Plus} onClick={() => setShowAdd(true)}>
                  Add your first client
                </Button>
              )
            }
          />
        </Card>
      ) : (
        <div className="clients-grid">
          {clients.map((client) => {
            const requests = getCurrentMonthRequests(client.id);
            const received = requests.filter(
              (r) => r.status === 'received' || r.status === 'reviewed'
            ).length;
            const lastUpload = requests
              .filter((r) => r.uploadedAt)
              .map((r) => new Date(r.uploadedAt))
              .sort((a, b) => b - a)[0];
            const overdue = requests.some(
              (r) => r.status === 'requested' && daysSince(r.requestedAt) > 14
            );
            const complete = requests.length > 0 && received === requests.length;

            return (
              <Link
                key={client.id}
                to={`/clients/${client.id}`}
                className="client-card-link"
              >
                <Card hoverable className="client-card">
                  <div className="client-card-header">
                    <Avatar
                      name={client.businessName}
                      color={client.avatarColor}
                      size="lg"
                    />
                    <ArrowUpRight
                      size={16}
                      strokeWidth={1.7}
                      className="client-card-arrow"
                    />
                  </div>

                  <div className="client-card-body">
                    <div className="client-card-industry">{client.industry}</div>
                    <h3 className="client-card-name">{client.businessName}</h3>
                    <div className="client-card-contact">
                      {client.contactName} · {client.email}
                    </div>
                  </div>

                  <div className="client-card-progress">
                    <div className="client-card-progress-row">
                      <span className="client-card-progress-label">This month</span>
                      <span className="mono client-card-progress-count">
                        {received}/{requests.length}
                      </span>
                    </div>
                    <Progress
                      value={received}
                      total={requests.length || 1}
                      variant={
                        complete
                          ? 'success'
                          : overdue
                          ? 'danger'
                          : received > 0
                          ? 'accent'
                          : 'warning'
                      }
                    />
                  </div>

                  <div className="client-card-footer">
                    {complete ? (
                      <Badge variant="success" dot>Complete</Badge>
                    ) : overdue ? (
                      <Badge variant="danger" dot>Overdue</Badge>
                    ) : received === 0 ? (
                      <Badge variant="warning" dot>Not started</Badge>
                    ) : (
                      <Badge variant="accent" dot>In progress</Badge>
                    )}
                    <span className="client-card-time">
                      {lastUpload ? `Updated ${timeAgo(lastUpload)}` : 'No uploads yet'}
                    </span>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}

      <Modal
        isOpen={showAdd}
        onClose={() => setShowAdd(false)}
        title="Add a new client"
        description="They'll start receiving automated document requests on the next cycle."
      >
        <form onSubmit={handleAdd} className="form-grid">
          <Input
            label="Business name"
            placeholder="Acme Coffee Co."
            value={form.businessName}
            onChange={(e) => setForm({ ...form, businessName: e.target.value })}
            required
          />
          <div className="form-row">
            <Input
              label="Contact name"
              placeholder="Marcus Chen"
              value={form.contactName}
              onChange={(e) => setForm({ ...form, contactName: e.target.value })}
            />
            <Input
              label="Industry"
              placeholder="Food & Beverage"
              value={form.industry}
              onChange={(e) => setForm({ ...form, industry: e.target.value })}
            />
          </div>
          <div className="form-row">
            <Input
              label="Email"
              type="email"
              placeholder="marcus@acme.com"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
            <Input
              label="Phone (for SMS)"
              placeholder="+1 (555) 555-0123"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
          </div>
          <Select
            label="Document template"
            value={form.templateId}
            onChange={(e) => setForm({ ...form, templateId: e.target.value })}
          >
            {templates.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </Select>
          <Textarea
            label="Notes (private)"
            placeholder="Anything to remember about this client…"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
          <div className="form-actions">
            <Button variant="ghost" type="button" onClick={() => setShowAdd(false)}>
              Cancel
            </Button>
            <Button variant="accent" type="submit">
              Add client
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
