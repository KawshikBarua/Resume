import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, FileText, Filter } from 'lucide-react';
import { useDocumentStore, useClientStore } from '@/store';
import { Card, Input, Badge, Avatar, Select, EmptyState } from '@/components/ui';
import { timeAgo, formatFileSize, daysSince } from '@/lib/utils';
import './Documents.css';

export function DocumentsPage() {
  const requests = useDocumentStore((s) => s.requests);
  const getClient = useClientStore((s) => s.getClient);

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [periodFilter, setPeriodFilter] = useState('all');

  const periods = [...new Set(requests.map((r) => r.period))];

  const filtered = requests.filter((r) => {
    const client = getClient(r.clientId);
    if (!client) return false;

    if (search) {
      const q = search.toLowerCase();
      const matches =
        r.label.toLowerCase().includes(q) ||
        client.businessName.toLowerCase().includes(q) ||
        (r.fileName && r.fileName.toLowerCase().includes(q));
      if (!matches) return false;
    }

    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    if (periodFilter !== 'all' && r.period !== periodFilter) return false;

    return true;
  }).sort((a, b) => {
    // Pending first, then by most recent activity
    const aPending = a.status === 'requested';
    const bPending = b.status === 'requested';
    if (aPending !== bPending) return bPending - aPending;
    const aDate = new Date(a.uploadedAt || a.requestedAt);
    const bDate = new Date(b.uploadedAt || b.requestedAt);
    return bDate - aDate;
  });

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">Library</div>
          <h1 className="page-title">All documents</h1>
          <p className="page-description">
            Search across every document request, uploaded file, and pending item from all your clients.
          </p>
        </div>
      </div>

      <div className="docs-toolbar">
        <Input
          icon={Search}
          placeholder="Search documents, clients, filenames…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="docs-search"
        />
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">All statuses</option>
          <option value="requested">Pending</option>
          <option value="received">Received</option>
          <option value="reviewed">Reviewed</option>
        </Select>
        <Select value={periodFilter} onChange={(e) => setPeriodFilter(e.target.value)}>
          <option value="all">All periods</option>
          {periods.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </Select>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={FileText}
            title="No documents match"
            description="Try a different search term or filter combination."
          />
        </Card>
      ) : (
        <Card>
          <div className="docs-grid">
            <div className="docs-grid-header">
              <div>Document</div>
              <div>Client</div>
              <div>Period</div>
              <div>Activity</div>
              <div>Status</div>
            </div>
            {filtered.slice(0, 100).map((req) => {
              const client = getClient(req.clientId);
              const overdue = req.status === 'requested' && daysSince(req.requestedAt) > 14;
              return (
                <Link key={req.id} to={`/clients/${req.clientId}`} className="docs-grid-row">
                  <div className="docs-grid-cell-doc">
                    <FileText size={14} strokeWidth={1.7} className="docs-grid-icon" />
                    <div>
                      <div className="docs-grid-label">{req.label}</div>
                      {req.fileName && (
                        <div className="docs-grid-filename mono">
                          {req.fileName} · {formatFileSize(req.fileSize)}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="docs-grid-cell-client">
                    <Avatar name={client.businessName} color={client.avatarColor} size="xs" />
                    <span>{client.businessName}</span>
                  </div>
                  <div className="docs-grid-period">{req.period}</div>
                  <div className="docs-grid-time">
                    {req.uploadedAt ? `Uploaded ${timeAgo(req.uploadedAt)}` : `Requested ${timeAgo(req.requestedAt)}`}
                  </div>
                  <div>
                    {req.status === 'reviewed' ? <Badge variant="success" dot>Reviewed</Badge> :
                     req.status === 'received' ? <Badge variant="accent" dot>To review</Badge> :
                     overdue ? <Badge variant="danger" dot>Overdue</Badge> :
                     <Badge variant="warning" dot>Pending</Badge>}
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}
