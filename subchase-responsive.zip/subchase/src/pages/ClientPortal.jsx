import { useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  UploadCloud, CheckCircle2, FileText, Shield, Lock, Sparkles, X,
} from 'lucide-react';
import { useDocumentStore, useClientStore, useAuthStore, useUIStore } from '@/store';
import { Button, Badge, EmptyState } from '@/components/ui';
import { currentPeriod, timeAgo, formatFileSize } from '@/lib/utils';
import './ClientPortal.css';

// Public-facing portal — what the client sees from their tokenized link.
export function ClientPortalPage() {
  const { clientId } = useParams();
  // For demo, we accept any client ID, defaulting to first if invalid
  const client = useClientStore((s) => s.getClient(clientId)) || useClientStore((s) => s.clients[0]);
  const getCurrentMonthRequests = useDocumentStore((s) => s.getCurrentMonthRequests);
  const markReceived = useDocumentStore((s) => s.markReceived);
  const firm = useAuthStore((s) => s.firm);
  const pushToast = useUIStore((s) => s.pushToast);

  const [draggedOver, setDraggedOver] = useState(null);

  const requests = client ? getCurrentMonthRequests(client.id) : [];
  const pending = requests.filter((r) => r.status === 'requested');
  const completed = requests.filter((r) => r.status !== 'requested');

  const handleUpload = (request) => {
    // Simulate file upload
    const fakeFileName = `${request.label.toLowerCase().replace(/\s+/g, '_')}_${Date.now()}.pdf`;
    const fakeSize = 200000 + Math.floor(Math.random() * 500000);
    markReceived(request.id, fakeFileName, fakeSize);
    pushToast({
      title: 'Uploaded',
      description: `${request.label} sent to ${firm.name}.`,
      variant: 'success',
    });
  };

  if (!client) {
    return (
      <div className="portal-page">
        <EmptyState
          icon={Lock}
          title="Invalid or expired link"
          description="This upload link has expired. Please ask your bookkeeper for a new one."
        />
      </div>
    );
  }

  return (
    <div className="portal-page">
      <header className="portal-header">
        <div className="portal-header-inner">
          <div className="portal-brand">
            <svg width="28" height="28" viewBox="0 0 32 32">
              <rect width="32" height="32" rx="7" fill="var(--ink)" />
              <text x="16" y="22" fontFamily="Fraunces, Georgia, serif" fontSize="18" fontWeight="600" fill="var(--accent)" textAnchor="middle">S</text>
            </svg>
            <span className="portal-brand-name">{firm.name}</span>
          </div>
          <div className="portal-secure">
            <Shield size={13} strokeWidth={1.8} />
            <span>Secure upload · No login needed</span>
          </div>
        </div>
      </header>

      <main className="portal-main">
        <div className="portal-hero">
          <div className="page-eyebrow">{currentPeriod()}</div>
          <h1 className="portal-title">
            Hi {client.contactName.split(' ')[0]} — a few things for your books.
          </h1>
          <p className="portal-sub">
            {firm.ownerName} from {firm.name} needs the documents below to close out{' '}
            <strong>{currentPeriod()}</strong>. Drag and drop, or click to upload — no account required.
          </p>
        </div>

        {pending.length > 0 && (
          <section className="portal-section">
            <div className="portal-section-header">
              <div>
                <h2 className="portal-section-title">Still needed</h2>
                <p className="portal-section-sub">{pending.length} {pending.length === 1 ? 'item' : 'items'} remaining</p>
              </div>
              <Badge variant="warning">{pending.length} pending</Badge>
            </div>

            <div className="portal-requests">
              {pending.map((req) => (
                <div
                  key={req.id}
                  className={`portal-request ${draggedOver === req.id ? 'portal-request-dragover' : ''}`}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDraggedOver(req.id);
                  }}
                  onDragLeave={() => setDraggedOver(null)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDraggedOver(null);
                    handleUpload(req);
                  }}
                >
                  <div className="portal-request-icon">
                    <FileText size={18} strokeWidth={1.6} />
                  </div>
                  <div className="portal-request-info">
                    <div className="portal-request-label">
                      {req.label}
                      {req.required && <span className="doc-required">required</span>}
                    </div>
                    <div className="portal-request-meta">
                      {req.documentTypeName} · Requested {timeAgo(req.requestedAt)}
                    </div>
                  </div>
                  <div className="portal-request-drop">
                    <UploadCloud size={16} strokeWidth={1.7} />
                    <span>Drop file or click</span>
                  </div>
                  <Button variant="primary" size="sm" onClick={() => handleUpload(req)}>
                    Choose file
                  </Button>
                </div>
              ))}
            </div>
          </section>
        )}

        {completed.length > 0 && (
          <section className="portal-section">
            <div className="portal-section-header">
              <div>
                <h2 className="portal-section-title">Already received</h2>
                <p className="portal-section-sub">{firm.ownerName} has these — you're all set on them.</p>
              </div>
              <Badge variant="success">{completed.length} complete</Badge>
            </div>

            <div className="portal-requests">
              {completed.map((req) => (
                <div key={req.id} className="portal-request portal-request-complete">
                  <div className="portal-request-icon portal-icon-complete">
                    <CheckCircle2 size={18} strokeWidth={1.6} />
                  </div>
                  <div className="portal-request-info">
                    <div className="portal-request-label">{req.label}</div>
                    <div className="portal-request-meta">
                      {req.fileName && <span className="mono">{req.fileName}</span>}
                      {req.fileSize && ` · ${formatFileSize(req.fileSize)}`}
                      {req.uploadedAt && ` · ${timeAgo(req.uploadedAt)}`}
                    </div>
                  </div>
                  <Badge variant="success" dot>Received</Badge>
                </div>
              ))}
            </div>
          </section>
        )}

        {pending.length === 0 && (
          <div className="portal-allset">
            <Sparkles size={20} strokeWidth={1.6} />
            <div>
              <div className="portal-allset-title">All caught up for this period.</div>
              <div className="portal-allset-sub">Thanks for being on top of it — {firm.ownerName} appreciates it.</div>
            </div>
          </div>
        )}

        <footer className="portal-footer">
          <div className="portal-footer-security">
            <Lock size={12} strokeWidth={1.8} />
            Encrypted in transit. Stored securely. Link expires in 60 days.
          </div>
          <div className="portal-footer-brand">
            Powered by <strong>SubChase</strong>
          </div>
        </footer>
      </main>
    </div>
  );
}
