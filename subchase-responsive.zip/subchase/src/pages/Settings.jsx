import { useState } from 'react';
import { Save, Mail, Shield, CreditCard } from 'lucide-react';
import { useAuthStore, useUIStore } from '@/store';
import { Card, CardBody, Button, Input, Select, Badge } from '@/components/ui';
import './Settings.css';

export function SettingsPage() {
  const firm = useAuthStore((s) => s.firm);
  const updateFirm = useAuthStore((s) => s.updateFirm);
  const pushToast = useUIStore((s) => s.pushToast);

  const [form, setForm] = useState({
    name: firm.name,
    ownerName: firm.ownerName,
    email: firm.email,
    phone: firm.phone,
    timezone: firm.timezone,
  });

  const handleSave = () => {
    updateFirm(form);
    pushToast({
      title: 'Settings saved',
      description: 'Your firm profile has been updated.',
      variant: 'success',
    });
  };

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">Account</div>
          <h1 className="page-title">Settings</h1>
          <p className="page-description">
            Manage your firm profile, email cadences, and billing.
          </p>
        </div>
      </div>

      <div className="settings-grid">
        <nav className="settings-nav">
          <a href="#profile" className="settings-nav-link settings-nav-active">Firm profile</a>
          <a href="#email" className="settings-nav-link">Email & reminders</a>
          <a href="#security" className="settings-nav-link">Security</a>
          <a href="#billing" className="settings-nav-link">Billing</a>
        </nav>

        <div className="settings-content">
          <Card id="profile">
            <CardBody>
              <div className="settings-section-header">
                <h3 className="settings-section-title">Firm profile</h3>
                <p className="settings-section-sub">This is what clients see in emails and on the upload portal.</p>
              </div>
              <div className="form-grid">
                <Input
                  label="Firm name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
                <Input
                  label="Owner / Primary contact"
                  value={form.ownerName}
                  onChange={(e) => setForm({ ...form, ownerName: e.target.value })}
                />
                <Input
                  label="Email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
                <Input
                  label="Phone"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                />
                <Select
                  label="Timezone"
                  value={form.timezone}
                  onChange={(e) => setForm({ ...form, timezone: e.target.value })}
                  className="form-full"
                >
                  <option value="America/Los_Angeles">Pacific — Los Angeles</option>
                  <option value="America/Denver">Mountain — Denver</option>
                  <option value="America/Chicago">Central — Chicago</option>
                  <option value="America/New_York">Eastern — New York</option>
                </Select>
              </div>
              <div className="settings-actions">
                <Button variant="primary" icon={Save} onClick={handleSave}>Save changes</Button>
              </div>
            </CardBody>
          </Card>

          <Card id="email">
            <CardBody>
              <div className="settings-section-header">
                <div>
                  <h3 className="settings-section-title">Email & reminders</h3>
                  <p className="settings-section-sub">Configure how often SubChase nudges your clients.</p>
                </div>
                <Mail size={18} strokeWidth={1.7} className="settings-section-icon" />
              </div>

              <div className="settings-cadence">
                <div className="cadence-row">
                  <div className="cadence-day">Day 0</div>
                  <div className="cadence-info">
                    <div className="cadence-title">Initial request</div>
                    <div className="cadence-desc">Sent the moment the request is generated.</div>
                  </div>
                  <Badge variant="success" dot>Active</Badge>
                </div>
                <div className="cadence-row">
                  <div className="cadence-day">Day 7</div>
                  <div className="cadence-info">
                    <div className="cadence-title">First reminder</div>
                    <div className="cadence-desc">Friendly nudge if still missing.</div>
                  </div>
                  <Badge variant="success" dot>Active</Badge>
                </div>
                <div className="cadence-row">
                  <div className="cadence-day">Day 14</div>
                  <div className="cadence-info">
                    <div className="cadence-title">Second reminder</div>
                    <div className="cadence-desc">Slightly firmer. Also sent via SMS.</div>
                  </div>
                  <Badge variant="success" dot>Active</Badge>
                </div>
                <div className="cadence-row">
                  <div className="cadence-day">Day 21</div>
                  <div className="cadence-info">
                    <div className="cadence-title">Final reminder</div>
                    <div className="cadence-desc">Overdue notice, you're CC'd.</div>
                  </div>
                  <Badge variant="success" dot>Active</Badge>
                </div>
              </div>
            </CardBody>
          </Card>

          <Card id="security">
            <CardBody>
              <div className="settings-section-header">
                <div>
                  <h3 className="settings-section-title">Security</h3>
                  <p className="settings-section-sub">Upload links expire after 60 days of inactivity by default.</p>
                </div>
                <Shield size={18} strokeWidth={1.7} className="settings-section-icon" />
              </div>
              <div className="settings-security-row">
                <div>
                  <div className="settings-security-title">256-bit tokenized upload links</div>
                  <div className="settings-security-desc">Cryptographically random, scoped to the current period, revocable.</div>
                </div>
                <Badge variant="success" dot>Enabled</Badge>
              </div>
              <div className="settings-security-row">
                <div>
                  <div className="settings-security-title">File virus scanning</div>
                  <div className="settings-security-desc">Every upload is scanned before reaching your dashboard.</div>
                </div>
                <Badge variant="success" dot>Enabled</Badge>
              </div>
              <div className="settings-security-row">
                <div>
                  <div className="settings-security-title">Two-factor authentication</div>
                  <div className="settings-security-desc">Add a code from your authenticator app.</div>
                </div>
                <Button variant="secondary" size="sm">Set up</Button>
              </div>
            </CardBody>
          </Card>

          <Card id="billing">
            <CardBody>
              <div className="settings-section-header">
                <div>
                  <h3 className="settings-section-title">Billing</h3>
                  <p className="settings-section-sub">You're on the Small Firm plan. $59 / month.</p>
                </div>
                <CreditCard size={18} strokeWidth={1.7} className="settings-section-icon" />
              </div>
              <div className="settings-plans">
                <div className="plan-card">
                  <div className="plan-name">Solo</div>
                  <div className="plan-price"><span className="serif">$29</span>/mo</div>
                  <div className="plan-desc">Up to 10 clients</div>
                </div>
                <div className="plan-card plan-card-active">
                  <Badge variant="accent">Current plan</Badge>
                  <div className="plan-name">Small Firm</div>
                  <div className="plan-price"><span className="serif">$59</span>/mo</div>
                  <div className="plan-desc">Up to 30 clients</div>
                </div>
                <div className="plan-card">
                  <div className="plan-name">Growing Firm</div>
                  <div className="plan-price"><span className="serif">$129</span>/mo</div>
                  <div className="plan-desc">Up to 100 clients</div>
                </div>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
