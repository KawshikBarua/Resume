import { useState } from 'react';
import { ClipboardList, Plus, Calendar, FileText, Trash2 } from 'lucide-react';
import { useTemplateStore, useUIStore } from '@/store';
import { Card, CardBody, Button, Badge, Modal, Input, Textarea, Select, EmptyState } from '@/components/ui';
import './Templates.css';

const frequencyLabels = {
  monthly: 'Every month',
  quarterly: 'Every quarter',
  annually: 'Once a year',
};

export function TemplatesPage() {
  const templates = useTemplateStore((s) => s.templates);
  const addTemplate = useTemplateStore((s) => s.addTemplate);
  const deleteTemplate = useTemplateStore((s) => s.deleteTemplate);
  const pushToast = useUIStore((s) => s.pushToast);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form, setForm] = useState({
    name: '',
    description: '',
    frequency: 'monthly',
    dayOfMonth: 5,
    items: [],
  });
  const [newItem, setNewItem] = useState('');

  const handleAdd = () => {
    if (!form.name || form.items.length === 0) {
      pushToast({
        title: 'Add a name and at least one item',
        variant: 'error',
      });
      return;
    }
    addTemplate({
      ...form,
      items: form.items.map((label) => ({ documentTypeId: 'dt_004', label, required: true })),
    });
    pushToast({
      title: 'Template created',
      description: `${form.name} is ready to assign.`,
      variant: 'success',
    });
    setIsModalOpen(false);
    setForm({ name: '', description: '', frequency: 'monthly', dayOfMonth: 5, items: [] });
  };

  const handleDelete = (id, name) => {
    deleteTemplate(id);
    pushToast({ title: 'Template deleted', description: name, variant: 'default' });
  };

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">Automation</div>
          <h1 className="page-title">Document templates</h1>
          <p className="page-description">
            Define what you need from each kind of client once. SubChase generates the requests automatically on schedule.
          </p>
        </div>
        <div className="page-actions">
          <Button variant="primary" icon={Plus} onClick={() => setIsModalOpen(true)}>
            New template
          </Button>
        </div>
      </div>

      {templates.length === 0 ? (
        <Card>
          <EmptyState
            icon={ClipboardList}
            title="No templates yet"
            description="Create your first template to start automating monthly document requests."
            action={<Button variant="primary" icon={Plus} onClick={() => setIsModalOpen(true)}>New template</Button>}
          />
        </Card>
      ) : (
        <div className="templates-grid">
          {templates.map((tpl) => (
            <Card key={tpl.id} className="template-card">
              <CardBody>
                <div className="template-card-header">
                  <div>
                    <h3 className="template-card-title">{tpl.name}</h3>
                    <p className="template-card-description">{tpl.description}</p>
                  </div>
                  <button
                    className="template-delete"
                    onClick={() => handleDelete(tpl.id, tpl.name)}
                    aria-label="Delete template"
                  >
                    <Trash2 size={14} strokeWidth={1.7} />
                  </button>
                </div>

                <div className="template-card-meta">
                  <div className="template-meta-item">
                    <Calendar size={12} strokeWidth={1.7} />
                    {frequencyLabels[tpl.frequency]}
                  </div>
                  <div className="template-meta-item">
                    on day {tpl.dayOfMonth}
                  </div>
                </div>

                <div className="template-items-label">
                  {tpl.items.length} items
                </div>
                <ul className="template-items">
                  {tpl.items.map((item, idx) => (
                    <li key={idx} className="template-item">
                      <FileText size={11} strokeWidth={1.7} />
                      <span>{item.label}</span>
                      {item.required && <Badge variant="accent">required</Badge>}
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create a template"
        description="Group commonly requested documents into a reusable package."
        size="md"
      >
        <Input
          label="Template name"
          placeholder="e.g., Restaurant Monthly Close"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <Textarea
          label="Description"
          placeholder="What this template is for…"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="mt"
        />
        <div className="form-grid mt">
          <Select
            label="Frequency"
            value={form.frequency}
            onChange={(e) => setForm({ ...form, frequency: e.target.value })}
          >
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="annually">Annually</option>
          </Select>
          <Input
            label="Day of month"
            type="number"
            min="1"
            max="28"
            value={form.dayOfMonth}
            onChange={(e) => setForm({ ...form, dayOfMonth: parseInt(e.target.value) || 1 })}
          />
        </div>

        <div className="template-builder mt">
          <label className="input-label">Document items</label>
          <div className="template-builder-input">
            <Input
              placeholder="e.g., Business Checking Statement"
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newItem) {
                  setForm({ ...form, items: [...form.items, newItem] });
                  setNewItem('');
                }
              }}
            />
            <Button
              variant="secondary"
              icon={Plus}
              onClick={() => {
                if (newItem) {
                  setForm({ ...form, items: [...form.items, newItem] });
                  setNewItem('');
                }
              }}
            >
              Add
            </Button>
          </div>
          {form.items.length > 0 && (
            <ul className="template-builder-list">
              {form.items.map((item, idx) => (
                <li key={idx} className="template-builder-item">
                  <FileText size={12} strokeWidth={1.7} />
                  <span>{item}</span>
                  <button
                    onClick={() => setForm({ ...form, items: form.items.filter((_, i) => i !== idx) })}
                    aria-label="Remove"
                  >
                    <Trash2 size={12} strokeWidth={1.8} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="modal-actions">
          <Button variant="ghost" onClick={() => setIsModalOpen(false)}>Cancel</Button>
          <Button variant="primary" onClick={handleAdd}>Create template</Button>
        </div>
      </Modal>
    </div>
  );
}
