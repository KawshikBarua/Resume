import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Mail,
  Phone,
  Send,
  Link as LinkIcon,
  Download,
  FileText,
  CheckCircle2,
  Clock,
  MessageSquarePlus,
  Plus,
} from 'lucide-react';
import {
  useClientStore,
  useDocumentStore,
  useTemplateStore,
  useActivityStore,
  useUIStore,
} from '@/store';
import {
  Card,
  CardBody,
  Button,
  Badge,
  Avatar,
  Progress,
  Modal,
  Textarea,
  Input,
  EmptyState,
} from '@/components/ui';
import { timeAgo, formatFileSize, currentPeriod, daysSince } from '@/lib/utils';
import './ClientDetail.css';

export function ClientDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const client = useClientStore((s) => s.getClient(id));
  const getClientRequests = useDocumentStore((s) => s.getClientRequests);
  const markReviewed = useDocumentStore((s) => s.markReviewed);
  const requeueDocument = useDocumentStore((s) => s.requeueDocument);
  const addComment = useDocumentStore((s) => s.addComment);
  const addCustomRequest = useDocumentStore((s) => s.addCustomRequest);
  const getTemplate = useTemplateStore((s) => s.getTemplate);
  const logActivity = useActivityStore((s) => s.logActivity);
  const pushToast = useUIStore((s) => s.pushToast);

  const [commentReq, setCommentReq] = useState(null);
  const [commentText, setCommentText] = useState('');
  const [showAddDoc, setShowAddDoc] = useState(false);
  const [newDocLabel, setNewDocLabel] = useState('');
  const [showPortal, setShowPortal] = useState(false);

  if (!client) {
    return (
      <div className="page">
        <EmptyState
          icon={FileText}
          title="Client not found"
          description="This client may have been archived or deleted."
          action={<Button onClick={() => navigate('/clients')}>Back to clients</Button>}
        />
      </div>
    );
  }

  const currentRequests = getClientRequests(client.id, currentPeriod());
  const previousRequests = getClientRequests(client.id).filter(
    (r) => r.period !== currentPeriod()
  );
  const received = currentRequests.filter(
    (r) => r.status === 'received' || r.status === 'reviewed'
  ).length;
  const template = client.templateId ? getTemplate(client.templateId) : null;

  const handleSendReminder = () => {
    logActivity('reminder', client.id, `Reminder sent to ${client.businessName}`);
    pushToast({
      title: 'Reminder sent',
      description: `${client.contactName || client.businessName} will receive an email and SMS shortly.`,
      variant: 'success',
    });
  };

  const handleCopyPortalLink = () => {
    const link = `https://subchase.app/u/${client.id}-tok-${Math.random().toString(36).slice(2, 10)}`;
    if (navigator.clipboard) navigator.clipboard.writeText(link).catch(() => {});
    pushToast({
      title: 'Portal link copied',
      description: 'Share this with your client — no login required.',
      variant: 'success',
    });
  };

  const handleSaveComment = () => {
    if (commentReq && commentText.trim()) {
      addComment(commentReq.id, commentText);
      pushToast({ title: 'Comment saved', variant: 'success' });
    }
    setCommentReq(null);
    setCommentText('');
  };

  const handleAddDoc = (e) => {
    e.preventDefault();
    if (!newDocLabel.trim()) return;
    addCustomRequest(client.id, newDocLabel, 'dt_004');
    pushToast({
      title: 'Request added',
      description: `"${newDocLabel}" is now in this month's checklist.`,
      variant: 'success',
    });
    setNewDocLabel('');
    setShowAddDoc(false);
  };

  return (
    <div className="page">
      <Link to="/clients" className="back-link">
        <ArrowLeft size={14} strokeWidth={1.8} />
        All clients
      </Link>

      <div className="client-detail-header">
        <Avatar name={client.businessName} color={client.avatarColor} size="xl" />
        <div className="client-detail-meta">
          <div className="page-eyebrow">{client.industry}</div>
          <h1 className="client-detail-name">{client.businessName}</h1>
          <div className="client-detail-contact">
            <span><strong>{client.contactName}</strong></span>
            <span className="client-detail-dot">·</span>
            <a href={`mailto:${client.email}`} className="client-detail-link">
              <Mail size={12} strokeWidth={1.8} />
              {client.email}
            </a>
            <span className="client-detail-dot">·</span>
            <span className="client-detail-link">
              <Phone size={12} strokeWidth={1.8} />
              {client.phone}
            </span>
          </div>
          {client.notes && (
            <div className="client-detail-notes">
              <em>"{client.notes}"</em>
            </div>
          )}
        </div>
        <div className="client-detail-actions">
          <Button variant="secondary" icon={LinkIcon} onClick={handleCopyPortalLink}>
            Copy portal link
          </Button>
          <Button variant="secondary" onClick={() => setShowPortal(true)}>
            Preview portal
          </Button>
          <Button variant="accent" icon={Send} onClick={handleSendReminder}>
            Send reminder
          </Button>
        </div>
      </div>

      <div className="client-stat-strip">
        <Card>
          <CardBody>
            <div className="stat-label">Current period</div>
            <div className="stat-value">{currentPeriod()}</div>
            <div className="stat-meta">Template: {template?.name || '—'}</div>
          </CardBody>
        </Card>
        <Card>
          <CardBody>
            <div className="stat-label">This month's progress</div>
            <div className="stat-progress-row">
              <div className="stat-value mono">{received}/{currentRequests.length}</div>
              <Badge variant={received === currentRequests.length ? 'success' : 'accent'} dot>
                {received === currentRequests.length ? 'Complete' : 'In progress'}
              </Badge>
            </div>
            <Progress
              value={received}
              total={currentRequests.length || 1}
              variant={received === currentRequests.length ? 'success' : 'accent'}
              className="stat-progress-bar"
            />
          </CardBody>
        </Card>
        <Card>
          <CardBody>
            <div className="stat-label">Total uploads (all time)</div>
            <div className="stat-value">
              {currentRequests.filter((r) => r.uploadedAt).length +
                previousRequests.filter((r) => r.uploadedAt).length}
            </div>
            <div className="stat-meta">Across {1 + Math.ceil(previousRequests.length / 6)} months</div>
          </CardBody>
        </Card>
      </div>

      <div className="section">
        <div className="section-header">
          <div>
            <h2 className="section-title">{currentPeriod()} — document requests</h2>
            <p className="section-subtitle">
              {received} of {currentRequests.length} received.
            </p>
          </div>
          <Button variant="ghost" size="sm" icon={Plus} onClick={() => setShowAddDoc(true)}>
            Add request
          </Button>
        </div>

        <Card>
          {currentRequests.length === 0 ? (
            <EmptyState
              icon={FileText}
              title="No requests this month"
              description="Apply a template or add a custom request to start collecting."
            />
          ) : (
            <div className="doc-list">
              {currentRequests.map((req) => (
                <DocumentRow
                  key={req.id}
                  request={req}
                  onMarkReviewed={() => {
                    markReviewed(req.id);
                    logActivity('review', client.id, `Reviewed ${req.label} for ${client.businessName}`);
                    pushToast({ title: 'Marked as reviewed', variant: 'success' });
                  }}
                  onRequeue={() => {
                    requeueDocument(req.id);
                    pushToast({
                      title: 'Re-requested',
                      description: 'Client will get a fresh upload link.',
                      variant: 'warning',
                    });
                  }}
                  onComment={() => {
                    setCommentReq(req);
                    setCommentText(req.reviewerComment || '');
                  }}
                />
              ))}
            </div>
          )}
        </Card>
      </div>

      {previousRequests.length > 0 && (
        <div className="section">
          <div className="section-header">
            <div>
              <h2 className="section-title">History</h2>
              <p className="section-subtitle">Archived documents from prior months.</p>
            </div>
          </div>
          <Card>
            <div className="doc-list doc-list-compact">
              {previousRequests.slice(0, 8).map((req) => (
                <div key={req.id} className="doc-row doc-row-compact">
                  <div className="doc-row-icon">
                    <FileText size={14} strokeWidth={1.6} />
                  </div>
                  <div className="doc-row-info">
                    <div className="doc-row-label">{req.label}</div>
                    <div className="doc-row-meta">{req.period} · {req.fileName || '—'}</div>
                  </div>
                  <Badge variant="default">Archived</Badge>
                  <span className="doc-row-time">{timeAgo(req.uploadedAt)}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      <Modal
        isOpen={!!commentReq}
        onClose={() => setCommentReq(null)}
        title="Add a note to this document"
        description="Visible to you and your team. Not sent to the client."
        size="sm"
      >
        <Textarea
          placeholder="e.g., Statement is missing page 3 — please re-upload."
          value={commentText}
          onChange={(e) => setCommentText(e.target.value)}
          rows={4}
        />
        <div className="form-actions">
          <Button variant="ghost" onClick={() => setCommentReq(null)}>Cancel</Button>
          <Button variant="accent" onClick={handleSaveComment}>Save note</Button>
        </div>
      </Modal>

      <Modal
        isOpen={showAddDoc}
        onClose={() => setShowAddDoc(false)}
        title="Add a custom document request"
        description="One-off request for this client, this month only."
        size="sm"
      >
        <form onSubmit={handleAddDoc} className="form-grid">
          <Input
            label="What do you need?"
            placeholder="e.g., Q3 sales tax filing"
            value={newDocLabel}
            onChange={(e) => setNewDocLabel(e.target.value)}
            autoFocus
            required
          />
          <div className="form-actions">
            <Button variant="ghost" type="button" onClick={() => setShowAddDoc(false)}>
              Cancel
            </Button>
            <Button variant="accent" type="submit">Add to checklist</Button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={showPortal}
        onClose={() => setShowPortal(false)}
        title="What your client sees"
        description="The tokenized upload portal. No login, no app install."
        size="lg"
      >
        <div className="portal-preview">
          <div className="portal-preview-header">
            <div>
              <div className="portal-preview-firm">Whitmore & Co. Bookkeeping</div>
              <h3 className="portal-preview-greeting">
                Hi {client.contactName?.split(' ')[0] || 'there'},
              </h3>
              <p className="portal-preview-intro">
                We're closing out {currentPeriod()}. Please upload the following whenever you have a moment.
              </p>
            </div>
          </div>
          <div className="portal-preview-list">
            {currentRequests.slice(0, 6).map((req) => {
              const done = req.status === 'received' || req.status === 'reviewed';
              return (
                <div key={req.id} className={`portal-item ${done ? 'portal-item-done' : ''}`}>
                  <div className="portal-item-check">
                    {done ? <CheckCircle2 size={18} strokeWidth={2} /> : <Clock size={18} strokeWidth={1.7} />}
                  </div>
                  <div className="portal-item-info">
                    <div className="portal-item-label">{req.label}</div>
                    <div className="portal-item-meta">
                      {done ? `Received ${timeAgo(req.uploadedAt)}` : 'Drag a file here or tap to upload'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Modal>
    </div>
  );
}

function DocumentRow({ request, onMarkReviewed, onRequeue, onComment }) {
  const done = request.status === 'received' || request.status === 'reviewed';
  const reviewed = request.status === 'reviewed';
  const overdue =
    request.status === 'requested' && daysSince(request.requestedAt) > 14;

  return (
    <div className="doc-row">
      <div className={`doc-row-icon ${done ? 'doc-row-icon-done' : ''}`}>
        {done ? (
          <CheckCircle2 size={16} strokeWidth={1.8} />
        ) : (
          <FileText size={16} strokeWidth={1.6} />
        )}
      </div>
      <div className="doc-row-info">
        <div className="doc-row-label">
          {request.label}
          {request.required && <span className="doc-row-required">*</span>}
        </div>
        <div className="doc-row-meta">
          {request.fileName ? (
            <>
              <span className="mono">{request.fileName}</span>
              <span> · {formatFileSize(request.fileSize)}</span>
              <span> · uploaded {timeAgo(request.uploadedAt)}</span>
            </>
          ) : overdue ? (
            <span className="doc-row-overdue">
              Requested {daysSince(request.requestedAt)} days ago
            </span>
          ) : (
            <span>Requested {timeAgo(request.requestedAt)}</span>
          )}
          {request.reviewerComment && (
            <div className="doc-row-comment">
              <MessageSquarePlus size={11} strokeWidth={1.8} />
              {request.reviewerComment}
            </div>
          )}
        </div>
      </div>

      <div className="doc-row-status">
        {reviewed ? (
          <Badge variant="success" dot>Reviewed</Badge>
        ) : done ? (
          <Badge variant="accent" dot>Received</Badge>
        ) : overdue ? (
          <Badge variant="danger" dot>Overdue</Badge>
        ) : (
          <Badge variant="warning" dot>Awaiting</Badge>
        )}
      </div>

      <div className="doc-row-actions">
        {done && !reviewed && (
          <Button size="sm" variant="ghost" onClick={onMarkReviewed}>
            Mark reviewed
          </Button>
        )}
        {done && (
          <Button size="sm" variant="ghost" icon={Download}>
            Download
          </Button>
        )}
        <Button size="sm" variant="ghost" icon={MessageSquarePlus} onClick={onComment}>
          Note
        </Button>
        {done && (
          <Button size="sm" variant="ghost" onClick={onRequeue}>
            Re-request
          </Button>
        )}
      </div>
    </div>
  );
}
