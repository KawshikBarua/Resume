import { create } from 'zustand';
import { templates as seedTemplates } from '@/data/dummyData';
import { generateId } from '@/lib/utils';

export const useTemplateStore = create((set, get) => ({
  templates: seedTemplates,

  addTemplate: (templateData) => {
    const newTemplate = {
      id: generateId('tpl'),
      ...templateData,
    };
    set((state) => ({ templates: [...state.templates, newTemplate] }));
    return newTemplate;
  },

  updateTemplate: (id, updates) =>
    set((state) => ({
      templates: state.templates.map((t) =>
        t.id === id ? { ...t, ...updates } : t
      ),
    })),

  deleteTemplate: (id) =>
    set((state) => ({
      templates: state.templates.filter((t) => t.id !== id),
    })),

  getTemplate: (id) => get().templates.find((t) => t.id === id),
}));
