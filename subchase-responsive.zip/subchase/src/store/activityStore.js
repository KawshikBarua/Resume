import { create } from 'zustand';
import { activityLog as seedActivity } from '@/data/dummyData';
import { generateId } from '@/lib/utils';

export const useActivityStore = create((set, get) => ({
  activities: seedActivity,

  logActivity: (type, clientId, message) => {
    const newActivity = {
      id: generateId('act'),
      type,
      clientId,
      message,
      timestamp: new Date().toISOString(),
    };
    set((state) => ({
      activities: [newActivity, ...state.activities].slice(0, 100),
    }));
  },

  getRecent: (limit = 10) => get().activities.slice(0, limit),

  getClientActivities: (clientId) =>
    get().activities.filter((a) => a.clientId === clientId),
}));
