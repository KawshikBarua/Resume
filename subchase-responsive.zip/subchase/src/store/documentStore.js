import { create } from 'zustand';
import { documentRequests as seedRequests } from '@/data/dummyData';
import { generateId, currentPeriod } from '@/lib/utils';

export const useDocumentStore = create((set, get) => ({
  requests: seedRequests,

  getClientRequests: (clientId, period = null) => {
    const { requests } = get();
    let filtered = requests.filter((r) => r.clientId === clientId);
    if (period) {
      filtered = filtered.filter((r) => r.period === period);
    }
    return filtered;
  },

  getCurrentMonthRequests: (clientId) => {
    return get().getClientRequests(clientId, currentPeriod());
  },

  getClientProgress: (clientId) => {
    const requests = get().getCurrentMonthRequests(clientId);
    const total = requests.length;
    const received = requests.filter(
      (r) => r.status === 'received' || r.status === 'reviewed'
    ).length;
    return { total, received, pending: total - received };
  },

  getOverallStats: () => {
    const requests = get().requests.filter((r) => r.period === currentPeriod());
    const total = requests.length;
    const received = requests.filter(
      (r) => r.status === 'received' || r.status === 'reviewed'
    ).length;
    const reviewed = requests.filter((r) => r.status === 'reviewed').length;
    const pending = requests.filter((r) => r.status === 'requested').length;
    return { total, received, reviewed, pending };
  },

  markReceived: (requestId, fileName, fileSize) =>
    set((state) => ({
      requests: state.requests.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: 'received',
              uploadedAt: new Date().toISOString(),
              fileName,
              fileSize,
            }
          : r
      ),
    })),

  markReviewed: (requestId) =>
    set((state) => ({
      requests: state.requests.map((r) =>
        r.id === requestId ? { ...r, status: 'reviewed' } : r
      ),
    })),

  addComment: (requestId, comment) =>
    set((state) => ({
      requests: state.requests.map((r) =>
        r.id === requestId ? { ...r, reviewerComment: comment } : r
      ),
    })),

  requeueDocument: (requestId) =>
    set((state) => ({
      requests: state.requests.map((r) =>
        r.id === requestId
          ? { ...r, status: 'requested', uploadedAt: null, fileName: null, fileSize: null }
          : r
      ),
    })),

  addCustomRequest: (clientId, label, documentTypeId) => {
    const newRequest = {
      id: generateId('req'),
      clientId,
      templateId: null,
      label,
      documentTypeId,
      documentTypeName: label,
      required: true,
      requestedAt: new Date().toISOString(),
      period: currentPeriod(),
      status: 'requested',
      uploadedAt: null,
      fileName: null,
      fileSize: null,
      reviewerComment: null,
    };
    set((state) => ({ requests: [...state.requests, newRequest] }));
    return newRequest;
  },
}));
