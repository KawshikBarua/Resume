import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { firmProfile } from '@/data/dummyData';

export const useAuthStore = create(
  persist(
    (set) => ({
      isAuthenticated: true, // For demo, start logged in
      firm: firmProfile,

      login: (email, password) => {
        // Dummy auth: any email/password works
        set({ isAuthenticated: true, firm: firmProfile });
        return { success: true };
      },

      logout: () => {
        set({ isAuthenticated: false });
      },

      updateFirm: (updates) =>
        set((state) => ({
          firm: { ...state.firm, ...updates },
        })),
    }),
    {
      name: 'subchase-auth',
    }
  )
);
