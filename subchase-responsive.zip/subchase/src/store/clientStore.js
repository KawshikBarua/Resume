import { create } from 'zustand';
import { clients as seedClients } from '@/data/dummyData';
import { generateId } from '@/lib/utils';

export const useClientStore = create((set, get) => ({
  clients: seedClients,
  searchQuery: '',
  sortBy: 'staleness', // 'staleness' | 'name' | 'recent'

  setSearchQuery: (q) => set({ searchQuery: q }),
  setSortBy: (s) => set({ sortBy: s }),

  addClient: (clientData) => {
    const newClient = {
      id: generateId('cli'),
      status: 'active',
      createdAt: new Date().toISOString().slice(0, 10),
      avatarColor: ['#b8895f', '#6b8068', '#a8523d', '#c89b3f', '#9b6f47'][
        Math.floor(Math.random() * 5)
      ],
      ...clientData,
    };
    set((state) => ({ clients: [newClient, ...state.clients] }));
    return newClient;
  },

  updateClient: (id, updates) =>
    set((state) => ({
      clients: state.clients.map((c) => (c.id === id ? { ...c, ...updates } : c)),
    })),

  archiveClient: (id) =>
    set((state) => ({
      clients: state.clients.map((c) =>
        c.id === id ? { ...c, status: 'archived' } : c
      ),
    })),

  deleteClient: (id) =>
    set((state) => ({
      clients: state.clients.filter((c) => c.id !== id),
    })),

  getClient: (id) => get().clients.find((c) => c.id === id),

  getFilteredClients: () => {
    const { clients, searchQuery, sortBy } = get();
    let filtered = clients.filter((c) => c.status === 'active');

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (c) =>
          c.businessName.toLowerCase().includes(q) ||
          c.contactName.toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q)
      );
    }

    if (sortBy === 'name') {
      filtered.sort((a, b) => a.businessName.localeCompare(b.businessName));
    } else if (sortBy === 'recent') {
      filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    return filtered;
  },
}));
