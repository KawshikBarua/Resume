// Dummy data for SubChase MVP
// All data is generated client-side; mimics what a real bookkeeping firm would manage.

export const firmProfile = {
  id: 'firm_001',
  name: 'Whitmore & Co. Bookkeeping',
  logo: null,
  ownerName: 'Eleanor Whitmore',
  email: 'eleanor@whitmoreco.com',
  phone: '+1 (415) 555-0142',
  timezone: 'America/Los_Angeles',
  businessHours: '9:00 AM – 5:00 PM',
  plan: 'small_firm',
  trialEndsAt: null,
};

export const documentTypes = [
  { id: 'dt_001', name: 'Bank Statement', icon: 'Landmark', category: 'banking' },
  { id: 'dt_002', name: 'Credit Card Statement', icon: 'CreditCard', category: 'banking' },
  { id: 'dt_003', name: 'Payroll Report', icon: 'Users', category: 'payroll' },
  { id: 'dt_004', name: 'Receipts', icon: 'Receipt', category: 'expenses' },
  { id: 'dt_005', name: 'Sales Report', icon: 'TrendingUp', category: 'revenue' },
  { id: 'dt_006', name: 'Owner Expense Notes', icon: 'NotebookPen', category: 'expenses' },
  { id: 'dt_007', name: 'Loan Statement', icon: 'FileText', category: 'liabilities' },
  { id: 'dt_008', name: 'Invoices (Outgoing)', icon: 'FileSpreadsheet', category: 'revenue' },
  { id: 'dt_009', name: 'Vendor Bills', icon: 'FileBox', category: 'expenses' },
  { id: 'dt_010', name: '1099 Forms', icon: 'FileBadge', category: 'tax' },
];

export const templates = [
  {
    id: 'tpl_001',
    name: 'Standard Monthly Close',
    description: 'Monthly bookkeeping package for most small business clients',
    frequency: 'monthly',
    dayOfMonth: 5,
    items: [
      { documentTypeId: 'dt_001', label: 'Business Checking Statement', required: true },
      { documentTypeId: 'dt_001', label: 'Business Savings Statement', required: true },
      { documentTypeId: 'dt_002', label: 'Business Credit Card Statement', required: true },
      { documentTypeId: 'dt_003', label: 'Payroll Summary', required: true },
      { documentTypeId: 'dt_004', label: 'Receipts Folder', required: false },
      { documentTypeId: 'dt_006', label: 'Owner Expense Explanations', required: false },
    ],
  },
  {
    id: 'tpl_002',
    name: 'Quarterly Cleanup',
    description: 'Catch-up package for clients who skip months',
    frequency: 'quarterly',
    dayOfMonth: 10,
    items: [
      { documentTypeId: 'dt_001', label: 'All Bank Statements (3 months)', required: true },
      { documentTypeId: 'dt_002', label: 'All Credit Card Statements', required: true },
      { documentTypeId: 'dt_004', label: 'Receipts (3 months)', required: true },
      { documentTypeId: 'dt_007', label: 'Loan Statements', required: false },
    ],
  },
  {
    id: 'tpl_003',
    name: 'Year-End Package',
    description: 'Annual tax-prep document collection',
    frequency: 'annually',
    dayOfMonth: 15,
    items: [
      { documentTypeId: 'dt_001', label: 'December Bank Statements', required: true },
      { documentTypeId: 'dt_002', label: 'December Credit Card Statements', required: true },
      { documentTypeId: 'dt_010', label: '1099 Forms Issued', required: true },
      { documentTypeId: 'dt_005', label: 'Annual Sales Summary', required: true },
      { documentTypeId: 'dt_006', label: 'Year-End Adjustments', required: false },
    ],
  },
];

export const clients = [
  {
    id: 'cli_001',
    businessName: 'Lumière Coffee Roasters',
    contactName: 'Marcus Chen',
    email: 'marcus@lumierecoffee.com',
    phone: '+1 (415) 555-0188',
    industry: 'Food & Beverage',
    notes: 'Pays on the 1st. Marcus is responsive but his bookkeeper sister sometimes uploads instead.',
    templateId: 'tpl_001',
    status: 'active',
    createdAt: '2024-08-12',
    avatarColor: '#b8895f',
  },
  {
    id: 'cli_002',
    businessName: 'Cedar & Stone Construction',
    contactName: 'James Whitfield',
    email: 'james@cedarstone.build',
    phone: '+1 (510) 555-0211',
    industry: 'Construction',
    notes: 'Notoriously slow with receipts. Send 2nd reminder via SMS.',
    templateId: 'tpl_001',
    status: 'active',
    createdAt: '2024-03-04',
    avatarColor: '#6b8068',
  },
  {
    id: 'cli_003',
    businessName: 'Hazelwood Interior Design',
    contactName: 'Sophie Hazelwood',
    email: 'sophie@hazelwooddesign.co',
    phone: '+1 (415) 555-0166',
    industry: 'Professional Services',
    notes: 'Excellent at uploading on time. Wants quarterly P&L review.',
    templateId: 'tpl_001',
    status: 'active',
    createdAt: '2023-11-18',
    avatarColor: '#a8523d',
  },
  {
    id: 'cli_004',
    businessName: 'Northgate Veterinary Clinic',
    contactName: 'Dr. Priya Ramanathan',
    email: 'priya@northgatevet.com',
    phone: '+1 (650) 555-0344',
    industry: 'Healthcare',
    notes: 'Practice manager Lila handles uploads. CC her on reminders.',
    templateId: 'tpl_001',
    status: 'active',
    createdAt: '2024-01-22',
    avatarColor: '#c89b3f',
  },
  {
    id: 'cli_005',
    businessName: 'Bayview Yoga Studio',
    contactName: 'Amara Johnson',
    email: 'amara@bayviewyoga.com',
    phone: '+1 (415) 555-0277',
    industry: 'Wellness',
    notes: 'New client. First month with us — be patient with onboarding.',
    templateId: 'tpl_001',
    status: 'active',
    createdAt: '2025-03-15',
    avatarColor: '#9b6f47',
  },
  {
    id: 'cli_006',
    businessName: 'Ridgeline Engineering, LLC',
    contactName: 'Thomas Reyes',
    email: 'thomas@ridgelineeng.com',
    phone: '+1 (408) 555-0455',
    industry: 'Engineering',
    notes: 'Owner travels often. Expect 1-week lag on responses.',
    templateId: 'tpl_002',
    status: 'active',
    createdAt: '2024-06-08',
    avatarColor: '#6b8068',
  },
  {
    id: 'cli_007',
    businessName: 'Petal & Vine Florist',
    contactName: 'Isabelle Trang',
    email: 'isabelle@petalandvine.shop',
    phone: '+1 (415) 555-0599',
    industry: 'Retail',
    notes: 'Seasonal business. December and February are huge months.',
    templateId: 'tpl_001',
    status: 'active',
    createdAt: '2024-09-30',
    avatarColor: '#a8523d',
  },
  {
    id: 'cli_008',
    businessName: 'Whitebark Mountain Outfitters',
    contactName: 'Connor MacAlister',
    email: 'connor@whitebark.gear',
    phone: '+1 (530) 555-0712',
    industry: 'Retail',
    notes: 'Outdoor retailer. Inventory questions every quarter.',
    templateId: 'tpl_001',
    status: 'active',
    createdAt: '2024-02-14',
    avatarColor: '#b8895f',
  },
];

// Helper: build a deterministic document request set
function buildRequests(clientId, templateId, monthOffset = 0, statusOverrides = {}) {
  const template = templates.find((t) => t.id === templateId);
  if (!template) return [];

  const now = new Date();
  const requestDate = new Date(now.getFullYear(), now.getMonth() - monthOffset, template.dayOfMonth);
  const monthLabel = requestDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return template.items.map((item, idx) => {
    const id = `req_${clientId}_${monthOffset}_${idx}`;
    const override = statusOverrides[idx] || {};
    const docType = documentTypes.find((d) => d.id === item.documentTypeId);
    const daysAgo = override.daysAgo ?? Math.floor(Math.random() * 25);
    const uploadedAt =
      override.status === 'received' || override.status === 'reviewed'
        ? new Date(now - daysAgo * 86400000).toISOString()
        : null;

    return {
      id,
      clientId,
      templateId,
      label: item.label,
      documentTypeId: item.documentTypeId,
      documentTypeName: docType?.name || 'Document',
      required: item.required,
      requestedAt: requestDate.toISOString(),
      period: monthLabel,
      status: override.status || 'requested',
      uploadedAt,
      fileName: override.fileName || null,
      fileSize: override.fileSize || null,
      reviewerComment: override.comment || null,
    };
  });
}

// Build current-month requests with varied states for visual demo
const currentMonthRequests = [
  ...buildRequests('cli_001', 'tpl_001', 0, {
    0: { status: 'received', daysAgo: 3, fileName: 'lumiere_checking_oct.pdf', fileSize: 284532 },
    1: { status: 'received', daysAgo: 3, fileName: 'lumiere_savings_oct.pdf', fileSize: 142021 },
    2: { status: 'received', daysAgo: 2, fileName: 'amex_oct_statement.pdf', fileSize: 421003 },
    3: { status: 'reviewed', daysAgo: 5, fileName: 'gusto_payroll_oct.pdf', fileSize: 89234 },
  }),
  ...buildRequests('cli_002', 'tpl_001', 0, {
    0: { status: 'received', daysAgo: 8, fileName: 'cedar_chase_oct.pdf', fileSize: 312094 },
  }),
  ...buildRequests('cli_003', 'tpl_001', 0, {
    0: { status: 'reviewed', daysAgo: 1, fileName: 'hazelwood_bofa_oct.pdf', fileSize: 198445 },
    1: { status: 'reviewed', daysAgo: 1, fileName: 'hazelwood_savings_oct.pdf', fileSize: 145998 },
    2: { status: 'received', daysAgo: 1, fileName: 'capone_october.pdf', fileSize: 256118 },
    3: { status: 'received', daysAgo: 4, fileName: 'adp_october.pdf', fileSize: 67821 },
    4: { status: 'received', daysAgo: 2, fileName: 'receipts_oct_2025.zip', fileSize: 1240312 },
  }),
  ...buildRequests('cli_004', 'tpl_001', 0, {
    0: { status: 'received', daysAgo: 6, fileName: 'wells_checking_oct.pdf', fileSize: 332112 },
    1: { status: 'received', daysAgo: 6, fileName: 'wells_savings_oct.pdf', fileSize: 188776 },
    3: { status: 'received', daysAgo: 4, fileName: 'paychex_oct_summary.pdf', fileSize: 92011 },
  }),
  ...buildRequests('cli_005', 'tpl_001', 0, {}), // new client — nothing yet
  ...buildRequests('cli_006', 'tpl_002', 0, {
    0: { status: 'received', daysAgo: 12, fileName: 'q3_bank_statements.zip', fileSize: 1842000 },
  }),
  ...buildRequests('cli_007', 'tpl_001', 0, {
    0: { status: 'received', daysAgo: 2, fileName: 'petal_chase_oct.pdf', fileSize: 221045 },
    2: { status: 'received', daysAgo: 2, fileName: 'visa_business_oct.pdf', fileSize: 187233 },
  }),
  ...buildRequests('cli_008', 'tpl_001', 0, {
    0: { status: 'received', daysAgo: 10, fileName: 'whitebark_checking.pdf', fileSize: 412000 },
    1: { status: 'received', daysAgo: 10, fileName: 'whitebark_savings.pdf', fileSize: 198445 },
    2: { status: 'received', daysAgo: 9, fileName: 'amex_corp_oct.pdf', fileSize: 365221 },
    3: { status: 'reviewed', daysAgo: 7, fileName: 'gusto_payroll.pdf', fileSize: 78122 },
    4: { status: 'received', daysAgo: 6, fileName: 'receipts.zip', fileSize: 982044 },
    5: { status: 'received', daysAgo: 6, fileName: 'owner_notes.docx', fileSize: 24102 },
  }),
];

// Previous month — mostly reviewed/archived
const previousMonthRequests = clients.flatMap((client) =>
  buildRequests(client.id, client.templateId, 1, {
    0: { status: 'reviewed', daysAgo: 35, fileName: 'prev_statement_1.pdf', fileSize: 280000 },
    1: { status: 'reviewed', daysAgo: 33, fileName: 'prev_statement_2.pdf', fileSize: 165000 },
    2: { status: 'reviewed', daysAgo: 32, fileName: 'prev_cc.pdf', fileSize: 245000 },
    3: { status: 'reviewed', daysAgo: 30, fileName: 'prev_payroll.pdf', fileSize: 78000 },
    4: { status: 'reviewed', daysAgo: 28, fileName: 'prev_receipts.zip', fileSize: 1100000 },
    5: { status: 'reviewed', daysAgo: 28, fileName: 'prev_notes.docx', fileSize: 22000 },
  })
);

export const documentRequests = [...currentMonthRequests, ...previousMonthRequests];

export const activityLog = [
  {
    id: 'act_001',
    type: 'upload',
    clientId: 'cli_003',
    message: 'Hazelwood Interior Design uploaded 2 documents',
    timestamp: new Date(Date.now() - 1 * 3600000).toISOString(),
  },
  {
    id: 'act_002',
    type: 'reminder',
    clientId: 'cli_005',
    message: 'Reminder sent to Bayview Yoga Studio',
    timestamp: new Date(Date.now() - 3 * 3600000).toISOString(),
  },
  {
    id: 'act_003',
    type: 'upload',
    clientId: 'cli_001',
    message: 'Lumière Coffee Roasters uploaded credit card statement',
    timestamp: new Date(Date.now() - 6 * 3600000).toISOString(),
  },
  {
    id: 'act_004',
    type: 'review',
    clientId: 'cli_003',
    message: 'Reviewed Hazelwood payroll summary',
    timestamp: new Date(Date.now() - 8 * 3600000).toISOString(),
  },
  {
    id: 'act_005',
    type: 'request',
    clientId: 'cli_006',
    message: 'Quarterly cleanup request opened for Ridgeline Engineering',
    timestamp: new Date(Date.now() - 22 * 3600000).toISOString(),
  },
  {
    id: 'act_006',
    type: 'upload',
    clientId: 'cli_008',
    message: 'Whitebark Mountain Outfitters uploaded receipts.zip',
    timestamp: new Date(Date.now() - 30 * 3600000).toISOString(),
  },
];

export const emailTemplates = {
  initial: {
    subject: 'Documents needed for {{period}} — {{firm_name}}',
    body: `Hi {{first_name}},

Hope you're doing well. As we close out {{period}}, I'll need a few items from you to keep your books on track:

{{document_list}}

You can upload everything in one place here — no login required:
{{portal_link}}

Let me know if any of these are tricky to pull. Happy to walk through it.

Best,
{{firm_owner}}
{{firm_name}}`,
  },
  reminder_7: {
    subject: 'Friendly reminder: {{period}} documents',
    body: `Hi {{first_name}},

Just a friendly nudge — I'm still missing a few items for {{period}}:

{{missing_list}}

Quick upload link (no login):
{{portal_link}}

Thanks!
{{firm_owner}}`,
  },
  reminder_14: {
    subject: 'Following up on {{period}} documents',
    body: `Hi {{first_name}},

Following up again on {{period}}. I want to make sure we don't fall behind on your books. Still waiting on:

{{missing_list}}

If anything's blocking you from pulling these, just reply to this email and I'll help.

{{portal_link}}

{{firm_owner}}`,
  },
  reminder_21: {
    subject: 'Final reminder: {{period}} documents are overdue',
    body: `Hi {{first_name}},

The {{period}} documents are now overdue and your books are at risk of falling behind. Please upload the following at your earliest convenience:

{{missing_list}}

{{portal_link}}

If you need an extension or a phone call, let me know today.

{{firm_owner}}`,
  },
};
