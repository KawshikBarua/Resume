import { cn } from '@/lib/utils';
import './EmptyState.css';

export function EmptyState({ icon: Icon, title, description, action, className }) {
  return (
    <div className={cn('empty-state', className)}>
      {Icon && (
        <div className="empty-state-icon">
          <Icon size={28} strokeWidth={1.3} />
        </div>
      )}
      <h3 className="empty-state-title">{title}</h3>
      {description && <p className="empty-state-description">{description}</p>}
      {action && <div className="empty-state-action">{action}</div>}
    </div>
  );
}
