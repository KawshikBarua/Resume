import { cn } from '@/lib/utils';
import { getInitials } from '@/lib/utils';
import './Avatar.css';

export function Avatar({ name, color = '#b8895f', size = 'md', className }) {
  return (
    <div
      className={cn('avatar', `avatar-${size}`, className)}
      style={{ background: color }}
    >
      {getInitials(name)}
    </div>
  );
}
