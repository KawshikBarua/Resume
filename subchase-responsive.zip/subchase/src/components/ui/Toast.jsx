import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { useUIStore } from '@/store';
import { cn } from '@/lib/utils';
import './Toast.css';

const icons = {
  default: Info,
  success: CheckCircle2,
  error: AlertCircle,
  warning: AlertCircle,
};

export function ToastContainer() {
  const toasts = useUIStore((s) => s.toasts);
  const dismissToast = useUIStore((s) => s.dismissToast);

  return (
    <div className="toast-container">
      {toasts.map((toast) => {
        const Icon = icons[toast.variant] || Info;
        return (
          <div
            key={toast.id}
            className={cn('toast', `toast-${toast.variant}`)}
          >
            <Icon size={18} strokeWidth={1.8} className="toast-icon" />
            <div className="toast-content">
              <div className="toast-title">{toast.title}</div>
              {toast.description && (
                <div className="toast-description">{toast.description}</div>
              )}
            </div>
            <button
              className="toast-close"
              onClick={() => dismissToast(toast.id)}
              aria-label="Dismiss"
            >
              <X size={14} strokeWidth={1.8} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
