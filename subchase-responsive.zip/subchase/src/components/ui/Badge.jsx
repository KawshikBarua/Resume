import { cn } from '@/lib/utils';
import './Badge.css';

export function Badge({ variant = 'default', children, className, dot = false }) {
  return (
    <span className={cn('badge', `badge-${variant}`, className)}>
      {dot && <span className="badge-dot" />}
      {children}
    </span>
  );
}
