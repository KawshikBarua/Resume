import { forwardRef } from 'react';
import { cn } from '@/lib/utils';
import './Input.css';

export const Input = forwardRef(function Input(
  { label, error, icon: Icon, hint, className, ...props },
  ref
) {
  return (
    <div className={cn('input-group', className)}>
      {label && <label className="input-label">{label}</label>}
      <div className={cn('input-wrap', error && 'input-wrap-error', Icon && 'input-wrap-icon')}>
        {Icon && <Icon className="input-icon" size={16} strokeWidth={1.8} />}
        <input ref={ref} className="input" {...props} />
      </div>
      {error && <span className="input-error">{error}</span>}
      {hint && !error && <span className="input-hint">{hint}</span>}
    </div>
  );
});

export const Textarea = forwardRef(function Textarea(
  { label, error, hint, className, ...props },
  ref
) {
  return (
    <div className={cn('input-group', className)}>
      {label && <label className="input-label">{label}</label>}
      <div className={cn('input-wrap', error && 'input-wrap-error')}>
        <textarea ref={ref} className="input input-textarea" {...props} />
      </div>
      {error && <span className="input-error">{error}</span>}
      {hint && !error && <span className="input-hint">{hint}</span>}
    </div>
  );
});

export const Select = forwardRef(function Select(
  { label, error, hint, children, className, ...props },
  ref
) {
  return (
    <div className={cn('input-group', className)}>
      {label && <label className="input-label">{label}</label>}
      <div className={cn('input-wrap', error && 'input-wrap-error')}>
        <select ref={ref} className="input input-select" {...props}>
          {children}
        </select>
      </div>
      {error && <span className="input-error">{error}</span>}
      {hint && !error && <span className="input-hint">{hint}</span>}
    </div>
  );
});
