import { cn } from '@/lib/utils';
import './Button.css';

export function Button({
  variant = 'primary',
  size = 'md',
  children,
  className,
  icon: Icon,
  ...props
}) {
  return (
    <button
      className={cn('btn', `btn-${variant}`, `btn-${size}`, className)}
      {...props}
    >
      {Icon && <Icon size={size === 'sm' ? 14 : 16} strokeWidth={1.8} />}
      {children}
    </button>
  );
}
