import { cn } from '@/lib/utils';
import './Progress.css';

export function Progress({ value = 0, total = 100, className, variant = 'default' }) {
  const percent = total === 0 ? 0 : Math.min(100, (value / total) * 100);
  return (
    <div className={cn('progress', className)}>
      <div
        className={cn('progress-bar', `progress-bar-${variant}`)}
        style={{ width: `${percent}%` }}
      />
    </div>
  );
}
