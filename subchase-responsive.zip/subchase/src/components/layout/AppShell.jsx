import { useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Menu } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { ToastContainer } from '@/components/ui';
import { useUIStore } from '@/store';
import './AppShell.css';

export function AppShell() {
  const sidebarOpen = useUIStore((s) => s.sidebarOpen);
  const setSidebarOpen = useUIStore((s) => s.setSidebarOpen);
  const toggleSidebar = useUIStore((s) => s.toggleSidebar);
  const location = useLocation();

  // Close mobile drawer on route change
  useEffect(() => {
    if (typeof window !== 'undefined' && window.innerWidth <= 900) {
      setSidebarOpen(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  // Close drawer on initial mount if on mobile; reopen on resize up to desktop
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mql = window.matchMedia('(max-width: 900px)');
    const sync = () => {
      if (mql.matches) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    };
    sync();
    mql.addEventListener?.('change', sync);
    return () => mql.removeEventListener?.('change', sync);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Lock body scroll when mobile drawer is open
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const isMobile = window.innerWidth <= 900;
    if (sidebarOpen && isMobile) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [sidebarOpen]);

  return (
    <div className={`app-shell ${sidebarOpen ? 'app-shell-sidebar-open' : ''}`}>
      <Sidebar />
      {sidebarOpen && (
        <div
          className="app-shell-backdrop"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}
      <main className="app-main">
        <button
          className="app-mobile-menu"
          onClick={toggleSidebar}
          aria-label="Open menu"
          type="button"
        >
          <Menu size={18} strokeWidth={1.8} />
        </button>
        <Outlet />
      </main>
      <ToastContainer />
    </div>
  );
}
