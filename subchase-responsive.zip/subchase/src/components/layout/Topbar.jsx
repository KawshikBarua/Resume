import { Search, Bell, Sparkles } from 'lucide-react';
import { useAuthStore, useDocumentStore } from '@/store';
import { currentPeriod } from '@/lib/utils';
import './Topbar.css';

export function Topbar({ title, description, action }) {
  const firm = useAuthStore((s) => s.firm);
  const stats = useDocumentStore((s) => s.getOverallStats());

  return (
    <header className="topbar">
      <div className="topbar-inner">
        <div className="topbar-left">
          {title && (
            <div>
              <h1 className="topbar-title">{title}</h1>
              {description && <p className="topbar-description">{description}</p>}
            </div>
          )}
        </div>

        <div className="topbar-right">
          <div className="topbar-period">
            <Sparkles size={13} strokeWidth={1.7} />
            <span className="topbar-period-label">Current period</span>
            <span className="topbar-period-value">{currentPeriod()}</span>
          </div>

          <div className="topbar-stat">
            <span className="topbar-stat-value">{stats.received}/{stats.total}</span>
            <span className="topbar-stat-label">collected</span>
          </div>

          {action && <div>{action}</div>}
        </div>
      </div>
    </header>
  );
}
