import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  FileText,
  ClipboardList,
  Activity,
  Settings,
  LogOut,
} from 'lucide-react';
import { useAuthStore } from '@/store';
import { Avatar } from '@/components/ui';
import './Sidebar.css';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard', end: true },
  { to: '/clients', icon: Users, label: 'Clients' },
  { to: '/documents', icon: FileText, label: 'Documents' },
  { to: '/templates', icon: ClipboardList, label: 'Templates' },
  { to: '/activity', icon: Activity, label: 'Activity' },
];

export function Sidebar() {
  const firm = useAuthStore((s) => s.firm);
  const logout = useAuthStore((s) => s.logout);

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="sidebar-logo">
          <svg width="28" height="28" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
            <rect width="32" height="32" rx="7" fill="var(--ink)" />
            <text
              x="16"
              y="22"
              fontFamily="Fraunces, Georgia, serif"
              fontSize="18"
              fontWeight="600"
              fill="var(--accent)"
              textAnchor="middle"
            >
              S
            </text>
          </svg>
          <div className="sidebar-brand-text">
            <div className="sidebar-brand-name">SubChase</div>
            <div className="sidebar-brand-tagline">Documents, on autopilot</div>
          </div>
        </div>
      </div>

      <nav className="sidebar-nav">
        <div className="sidebar-section-label">Workspace</div>
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `sidebar-link ${isActive ? 'sidebar-link-active' : ''}`
            }
          >
            <item.icon size={16} strokeWidth={1.7} />
            <span>{item.label}</span>
          </NavLink>
        ))}

        <div className="sidebar-section-label sidebar-section-label-divider">Account</div>
        <NavLink
          to="/settings"
          className={({ isActive }) =>
            `sidebar-link ${isActive ? 'sidebar-link-active' : ''}`
          }
        >
          <Settings size={16} strokeWidth={1.7} />
          <span>Settings</span>
        </NavLink>
      </nav>

      <div className="sidebar-footer">
        <div className="sidebar-user">
          <Avatar name={firm.ownerName} color="var(--accent)" size="sm" />
          <div className="sidebar-user-info">
            <div className="sidebar-user-name">{firm.ownerName}</div>
            <div className="sidebar-user-firm">{firm.name}</div>
          </div>
          <button
            className="sidebar-logout"
            onClick={logout}
            title="Sign out"
            aria-label="Sign out"
          >
            <LogOut size={15} strokeWidth={1.7} />
          </button>
        </div>
      </div>
    </aside>
  );
}
