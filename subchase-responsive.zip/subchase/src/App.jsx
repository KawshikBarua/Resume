import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';
import { ProtectedRoute } from '@/components/layout/ProtectedRoute';
import {
  DashboardPage,
  ClientsPage,
  ClientDetailPage,
  DocumentsPage,
  TemplatesPage,
  ActivityPage,
  SettingsPage,
  LoginPage,
  ClientPortalPage,
} from '@/pages';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public client upload portal */}
        <Route path="/portal/:clientId" element={<ClientPortalPage />} />
        <Route path="/portal" element={<ClientPortalPage />} />

        {/* Login */}
        <Route path="/login" element={<LoginPage />} />

        {/* Protected app */}
        <Route
          element={
            <ProtectedRoute>
              <AppShell />
            </ProtectedRoute>
          }
        >
          <Route path="/" element={<DashboardPage />} />
          <Route path="/clients" element={<ClientsPage />} />
          <Route path="/clients/:id" element={<ClientDetailPage />} />
          <Route path="/documents" element={<DocumentsPage />} />
          <Route path="/templates" element={<TemplatesPage />} />
          <Route path="/activity" element={<ActivityPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
